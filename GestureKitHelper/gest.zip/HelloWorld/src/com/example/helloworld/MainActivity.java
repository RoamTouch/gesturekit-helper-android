package com.example.helloworld;


import com.roamotuch.gesturekit.plugin.GKActionInterface;
import com.roamtouch.gesturekit.GestureKit;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.ScaleAnimation;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.roamotuch.gesturekit.plugin.GKActionInterface;
import com.roamotuch.gesturekit.plugin.PluginInterface;
import com.roamtouch.gesturekit.GestureKit;
import com.gesturekit.gesturekithelper.GestureKitHelper;


public class MainActivity extends Activity implements GKActionInterface {
	GestureKit gesturekit;	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		//RelativeLayout rlGesturePad = (RelativeLayout) findViewById(R.id.rlGesturePad);
		//this.gesturekit = new GestureKit(this, "38381630-b759-4c55-91c1-985306dbe587"); 
		this.gesturekit = new GestureKit(this, "1eca832c-916c-4426-b6b1-1499b82756af");
		this.gesturekit.setPlugin((PluginInterface) new GestureKitHelper(this, this.gesturekit));		
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	
     public String getActionID() {
         return "HELP";        
        }

        public void onGestureRecognized(Object... params){
            Log.e("Success","gesture PLAY recognized!");
          //Let's do something cool
     }
}
