package com.roamtouch.gesturekit;

import com.roamotuch.gesturekit.plugin.PluginInterface;

import android.app.Activity;
import android.webkit.JavascriptInterface;


public class GestureBridge {
	
	private GestureKit gesturekit;
	private Activity activity;
	private PluginInterface visor;
	
	public GestureBridge(GestureKit g, Activity context, PluginInterface visor){		
		this.gesturekit = g;
		this.activity = context;
		this.visor = visor;
	}
	
	@JavascriptInterface
	public void error (String e) {
		GestureKit.getLogger().LogV("error: " + e);
	}
	
	@JavascriptInterface
	public void outPut (String o) {
		GestureKit.getLogger().LogV("output: " + o);		
	}
	
	@JavascriptInterface
	public void clearGesture () {
		activity.runOnUiThread(new Runnable() {		 
			@Override
			public void run() {   
				visor.clear();
		     }
        }); 
		
	}
	
	@JavascriptInterface
	public void recognize(String method) throws ClassNotFoundException{
		GestureKit.getLogger().LogV("Recognized Gesture: '" + method + "'");
		gesturekit.executeMethod(method);		
	}
}