package com.roamtouch.gesturekit.data;
import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.List;

import android.graphics.PointF;
import android.text.TextUtils;
import android.util.SparseArray;

public class GKPoint {
	private Double x;
	private Double y;
	private int strokeId;

	public GKPoint()
	{
		strokeId = 0;
	}

	public GKPoint(double x, double y, int strokeId)
	{
		this.x = x;
		this.y = y;
		this.strokeId = strokeId;
	}

	public double getX() {
		return x;
	}
	public void setX(Double x) {
		this.x = x;
	}

	public double getY() {
		return this.y;
	}

	public void setY(Double y) {
		this.y = y;
	}

	public int getStrokeId() {
		return this.strokeId;
	}

	public void setStrokeId(int strokeId) {
		this.strokeId = strokeId;
	}

	public Gesture getGesture()
	{
		Gesture g = new Gesture();
		g.setID(this.strokeId);
		g.setX(this.x.toString());
		g.setY(this.y.toString());
		return g;
	}

	public static Gesture[] getGestures(GKPoint[] points)
	{
		if(points == null)
			return null;

		int size = points.length;

		Gesture[] result = new Gesture[size];
		for(int i=0;i<size;i++)
			result[i] = points[i].getGesture();

		return result;
	}

	public static ArrayList<GKPoint> getGKPointsList(SparseArray<List<PointF>> pointMap)
	{
		if(pointMap == null)
			return null;

		ArrayList<GKPoint> result = new ArrayList<GKPoint>();

		int key = 0;		
		for(int i = 0; i < pointMap.size(); i++) {
			key = pointMap.keyAt(i);
			// get the object by the key.
			ArrayList<PointF> points = (ArrayList<PointF>)pointMap.get(key);
			if(points!=null && points.size() > 1)
				for(int j=0;j<points.size();j++)
					result.add(new GKPoint(points.get(j).x, points.get(j).y, key));
		}

		return result;
	}

	public static GKPoint[] getGKPoints(SparseArray<List<PointF>> pointMap)
	{
		return getGKPointsArray(getGKPointsList(pointMap));
	}
	
	public static GKPoint[] getGKPointsArray(ArrayList<GKPoint> pointMap)
	{
		GKPoint[] result = new GKPoint[pointMap.size()];
		for(int i=0;i<pointMap.size();i++)
			result[i] = pointMap.get(i);
		return result;
	}
	/*
	 * Separates the elements of a GKPoint in the string representation.
	 */
	static final String LEVEL1 = ",";
	/*
	 * Separates the GKPoints in the string representation of a list.
	 */
	static final String LEVEL2 = ";";


	public String toString()
	{
		return this.strokeId + LEVEL1 + this.x + LEVEL1 + this.y;
	}
	/*
	 * Gets the string representation of the list of points.
	 */
	public static String toString(ArrayList<GKPoint> points)
	{
		ArrayList<String> strings = new ArrayList<String>();
		for(int i=0;i<points.size();i++)
			strings.add(points.get(i).toString());

		return TextUtils.join(LEVEL2, strings);
	}

	/*
	 * Gets a GKPoint from the given string.
	 */
	public static GKPoint fromString(String s)
	{
		try{
			String[] elems = s.split(LEVEL1); 
			if(elems.length != 3)
				return null;

			int strokeId =  Integer.parseInt(elems[0]);
			double x = Double.parseDouble(elems[1]);
			double y = Double.parseDouble(elems[2]);
			return new GKPoint(x, y, strokeId);
		}catch(Exception e)
		{
			return null;
		}
	}
	
	/*
	 * Parses the string into a list of GKPoints.
	 */
	public static ArrayList<GKPoint> listFromString(String s)
	{
		try{
			String[] elems = s.split(LEVEL2); 
			ArrayList<GKPoint> result = new ArrayList<GKPoint>();
			for(int i=0;i<elems.length;i++)
			{
				GKPoint temp = GKPoint.fromString(elems[i]);
				if(temp!=null)
					result.add(temp);
			}
			return result;
		}catch(Exception e)
		{
			return null;
		}
	}	
	
	/*
	 * Saves the array to shared preferences with the given app name as a key.
	 */
	public static boolean saveArray(Context c, String appName, ArrayList<GKPoint> points)
	{
		SharedPreferences prefs = GKPreferences.prefs(c);
		SharedPreferences.Editor editor = prefs.edit();
		editor.putString(appName, null); 
		editor.commit();
		editor.putString(appName, GKPoint.toString(points)); 
		return editor.commit();     
	}
	
	/*
	 * Loads a list of GKPoints from the shared preferences, using the app name as a key.
	 */
	public static ArrayList<GKPoint> loadArray(Context c, String appName)
	{
		SharedPreferences prefs = GKPreferences.prefs(c);
		String s = prefs.getString(appName, ""); 
		if(s == "")
			return null;
		return GKPoint.listFromString(s);
	}
}
