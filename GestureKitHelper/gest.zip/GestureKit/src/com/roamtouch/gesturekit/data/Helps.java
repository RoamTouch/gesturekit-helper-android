package com.roamtouch.gesturekit.data;

import java.util.ArrayList;
import java.util.List;

public class Helps {
	
	private String method;
	private String image;
	private String description;
	private String color;
	
	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	private List<List<Helps>> helps = new ArrayList<List<Helps>>();
	
	public Helps() {	}
	
	public String getMethod() {
		return method;
	}	
	public void setMethod(String method) {
		this.method = method;
	}
		
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	public List<List<Helps>> getHelps() {
		return helps;
	}	
}


