package com.roamtouch.gesturekit.data;

import java.util.Vector;

import org.json.JSONException;
import org.json.JSONObject;

import com.roamtouch.gesturekit.GestureKit;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

public class GKPreferences {
	//TODO Analytics preferences
	private static SharedPreferences.Editor prefs_editor;
	private static SharedPreferences prefs;
	private static Vector<String> prefs_vector = new Vector<String>();
	
	public static SharedPreferences prefs(Context c){
		if (prefs == null){
			// Set Basic Sharedpreferences for cache.		
			prefs = c.getSharedPreferences("GestureKit", Context.MODE_PRIVATE);		
			prefs_editor = prefs.edit();
		}
		return prefs;
	}
	
	public static void put(String key, boolean value){
		prefs_editor.putBoolean(key, value).commit();
	}
	
	public static void put(String key, int value){
		prefs_editor.putInt(key, value).commit();
	}
	
	public static void put(String key, String value){
		try{
			prefs_editor.putString(key, value).commit();
		} catch(Exception e)
		{
			Log.v("actionup", "Exception on actionup: " + e.getMessage());			
		}
	}
	
	public static void put(String key, long value){
		prefs_editor.putLong(key, value).commit();
	}
	
	public static String getString(String key){
		return prefs.getString(key, "");
	}
	
	public static long getLong(String key){
		return prefs.getLong(key, -1);
	}
	
	public static int getInt(String key){
		return prefs.getInt(key, -1);
	}
	
	public static boolean getBoolean(String key, boolean defaultValue){
		return prefs.getBoolean(key, defaultValue);
	}
	
	public static void putFloat(String key, float defaultValue){
		prefs_editor.putFloat(key, defaultValue).commit();
	}
	
	
	public int getInt(String key, int defaultValue){
		return prefs.getInt(key, defaultValue);			
	}
	
	/**
	 * add_data_to_cache
	 * @param key
	 * @param value
	 */
	public static void add_data_to_cache (String key, Object value) {		
		//Multi uiid supprt.
		String key_uiid = GestureKit.UIID + "_" + key;
		prefs_vector.add(key_uiid);	
		
		if (value instanceof Boolean){
			boolean v = (Boolean) value;
			put(key_uiid, v);			
		} else if (value instanceof Integer){ 	
			int i = (Integer) value;
			put(key_uiid, i);
		} else if (value instanceof String){ 
			put(key_uiid, value.toString());
		}
	}
	
	public static Cache set_prefs_values(JSONObject content, Cache c){
		
		String activity_name;
		String application_name;
		String application_description;
		String user_first_name;
		String user_last_name;
		
		try {
			activity_name = content.getString("name");
			add_data_to_cache("activity_name", activity_name);
			
			application_name = content.getString("application_name");
			add_data_to_cache("application_name", application_name);
			
			application_description = content.getString("application_description");
			add_data_to_cache("application_description", application_description);
			
			user_first_name = content.getString("user_first_name");
			add_data_to_cache("user_first_name", user_first_name);
			
			user_last_name = content.getString("user_last_name");
			add_data_to_cache("user_last_name", user_last_name);    			    	    	    	
	    	
	    	User u = new User();
	    	u.setDeveloper(GestureKit.developer);
	    	u.setApplication_name(application_name);			    	    	
	    	c.putUser("user", u);     
	    	
		} catch (JSONException e) {
			e.printStackTrace();
		}
		
		return c; 	   
	}	
	
	public static void clear_cache (){
		for (int i=0; i<prefs_vector.size(); i++){
			prefs_editor.remove((String) prefs_vector.get(i));
		}		
		prefs_editor.commit();
	}
}
