package com.roamtouch.gesturekit.data;

import java.util.ArrayList;
import java.util.List;

public class Gestures {
	
	private String method;
	private String metadata;
	private String color;
	
	private List<List<Gesture>> gestures = new ArrayList<List<Gesture>>();
		
	public Gestures() {	}
	
	// OPTIONAL LOCAL RKT
	private String packageName;
	
	public String getPackageName() {
		return packageName;
	}
	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}
	
	public String getMethod() {
		return method;
	}	
	public void setMethod(String method) {
		this.method = method;
	}
	
	public String getMetadata() {
		return metadata;
	}
	public void setMetadata(String metadata) {
		this.metadata = "null".equals(metadata)?null:metadata;
	}
	
	public String getColor() {
		return color;
	}	
	public void setColor(String color) {
		this.color = color;
	}

	public List<List<Gesture>> getGestures() {
		return gestures;
	}	
	
	public void setGestures(List<List<Gesture>> gestures) {
		this.gestures = gestures;
	}
}


