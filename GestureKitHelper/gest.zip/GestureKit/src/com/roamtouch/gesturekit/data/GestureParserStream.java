package com.roamtouch.gesturekit.data;
  
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
  
import android.util.JsonReader;
import android.util.JsonToken;
  
import com.roamtouch.gesturekit.communications.GestureTask.GestureListener;
import com.roamtouch.gesturekit.communications.GestureTask.onGestureProgressUpdate;
  
public class GestureParserStream {
   
	private static final String FIELD_NAME =                "gestureset_name";
    private static final String FIELD_GID =                 "gid";
    private static final String FIELD_GESTURES =            "gestures";
    private static final String FIELD_METHOD =          "method";
    private static final String FIELD_METADATA =            "metadata";
    private static final String FIELD_COLOR =           "color";
    private static final String FIELD_GESTURE =             "gesture";
    private static final String FIELD_ID =              "ID";
    private static final String FIELD_X =               "X";
    private static final String FIELD_Y =               "Y";
     
    public GestureParserStream (){
    	
    }
    
    public Cache parse (Cache cache, String urlString, String package_name, onGestureProgressUpdate onGestureProgressUpdate, GestureListener gestureListener ) throws IOException {
        GestureSet gestureSet = null;
        JsonReader jsonReader = null;
        try{
            URL url = new URL(urlString);
            jsonReader = new JsonReader(new InputStreamReader(url.openStream()));
            gestureSet = parseGestureSet(jsonReader);
        }finally {
            jsonReader.close();
        }
         
        cache.putGestureSet(gestureSet.getGid(), gestureSet);
             
        return cache;
    }
     
    public GestureSet parseGestureSet(JsonReader jsonReader) throws IOException{
        GestureSet gestureSet = new GestureSet();
         
        jsonReader.beginObject();
        jsonReader.nextName();
        jsonReader.beginObject();
        while (jsonReader.hasNext()){
            String name = jsonReader.nextName();
            if (FIELD_NAME.equals(name)) {
                gestureSet.setName(jsonReader.nextString());
            }else if (FIELD_GID.equals(name)) {
                String aux = jsonReader.nextString();
                gestureSet.setGid(aux);
            }else if (FIELD_GESTURES.equals(name)){
                parseGestures(jsonReader, gestureSet);
            }else{
                jsonReader.skipValue();
            }
  
        }
        //jsonReader.endObject();
         
        return gestureSet;
    }
     
    private void parseGestures(JsonReader jsonReader, GestureSet gestureSet) throws IOException{
        Gestures gestures = new Gestures();
        Map<String, Gestures> map = new HashMap<String, Gestures>();
        String method;
        jsonReader.beginArray();
        while (jsonReader.hasNext()) {
            jsonReader.beginObject();
            while (jsonReader.hasNext()) {
                String name = jsonReader.nextName();
                if(FIELD_METHOD.equals(name)){
                    method = jsonReader.nextString();
                    if(map.containsKey(method))
                        gestures = map.get(method);
                    else{
                        gestures = new Gestures();
                        gestures.setMethod(method);
                        map.put(method, gestures);
                        gestureSet.getGestures().add(gestures);
                    }
                }else if(FIELD_METADATA.equals(name) && jsonReader.peek() == JsonToken.STRING){
                    gestures.setMetadata(jsonReader.nextString());
                }else if(FIELD_COLOR.equals(name)){
                    gestures.setColor(jsonReader.nextString());
                }else if(FIELD_GESTURE.equals(name)){
                    jsonReader.beginArray();
                    List<Gesture> list = new ArrayList<Gesture>();
                    while (jsonReader.hasNext()){
                        list.add(parseGesture(jsonReader));
                    }
                    jsonReader.endArray();
                    gestures.getGestures().add(list);
                }else
                    jsonReader.skipValue();                                             
            }
            jsonReader.endObject();
        }
    }
     
    private Gesture parseGesture(JsonReader jsonReader) throws IOException{
        jsonReader.beginObject();
        Gesture gesture = new Gesture();
        String name;
        while (jsonReader.hasNext()){
            name = jsonReader.nextName();
            if(FIELD_ID.equals(name)){
                gesture.setID(jsonReader.nextInt());
            }else if(FIELD_X.equals(name)){
                gesture.setX(jsonReader.nextString());
            }else if(FIELD_Y.equals(name)){
                gesture.setY(jsonReader.nextString());
            }else
                jsonReader.skipValue();
        }
        jsonReader.endObject();
        return gesture;
    }
}
