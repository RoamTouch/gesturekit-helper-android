package com.roamtouch.gesturekit.data;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.roamtouch.gesturekit.communications.HelpTask.HelpListener;
import com.roamtouch.gesturekit.communications.HelpTask.onHelpProgressUpdate;

public class HelpParserJackson {

	public Cache parse (Cache cache, String url, String package_name, onHelpProgressUpdate onHelpProgressUpdate, HelpListener helpListener ) throws JsonParseException, IOException {
		
		JsonFactory jsonFactory = new JsonFactory();
		JsonParser jp = jsonFactory.createParser(new URL(url));
		
		HelpSet helpsSet= new HelpSet();
		
		//really ugly but efficient parser		
		/*jp.nextValue();
		jp.nextValue();
		jp.nextValue();
		helpsSet.setName(jp.getText());
		jp.nextValue();
		helpsSet.setGid(jp.getText());
		jp.nextValue();
		jp.nextValue();
		
		Helps helps = null;
		Map<String, Helps> map = new HashMap<String, Helps>();
		String method;
		while(jp.getCurrentToken() != JsonToken.END_ARRAY){
			jp.nextValue();
			method = jp.getText();
			if(map.containsKey(method))
				helps = map.get(method);
			else{
				helps = new Helps();
				helps.setMethod(method);
				map.put(method, helps);
				helpsSet.getHelps().add(helps);
			}
			jp.nextValue();
			if("img".equals(jp.getCurrentName())){
				helps.setImage(jp.getText());
				jp.nextValue();
				cache.putHelps(method, new HelpSet(helps.getImage(), helps.getDescription())));
			}
			jp.nextValue();
			if("img_description".equals(jp.getCurrentName())){
				helps.setDescription(jp.getText());
				jp.nextValue();
				cache.putHelps(new MethodHelp(method, helps.getImage(), helps.getDescription()));
			}
		
		}
		cache.putHelpSet(helpsSet);   	*/  

		return cache;
	}
}
