package com.roamtouch.gesturekit.data;

import java.io.StringWriter;
import java.util.List;

public class JSONGenerator {
	//export JSON manually is 100% faster than export by Jackson or org.json 	

	public static String getHelpJSON(HelpSet helpSet){
		StringWriter writer = new StringWriter(1024);
		writer.write("[");
		boolean isNotFirst = false;
		for(Helps helps : helpSet.getHelps()){
			if(isNotFirst)
				writer.write(',');
			else
				isNotFirst = true;	
			writer.write("{\"name\":\""+helps.getMethod()+"\",\"image\":\""+helps.getImage()+"\",\"description\":\""+helps.getDescription()+"\"}");
		}
		writer.write("]");
		return writer.toString();
	}

	public static String getJSON(GestureSet gestureSet){
		StringWriter writer = new StringWriter(1048576);
		writer.write('[');
		boolean isNotFirst = false;
		for(Gestures gestures : gestureSet.getGestures()){
			for(List<Gesture> gestureList : gestures.getGestures()){
				if(isNotFirst)
					writer.write(',');
				else
					isNotFirst = true;	
				writer.write("{\"method\":\""+gestures.getMethod()+"\",");
				writer.write("\"gesture\":[{\"ID\":\""+gestureList.get(0).getID()+"\",\"X\":\""+gestureList.get(0).getX()+"\",\"Y\":\""+gestureList.get(0).getY()+"\"}");
				for(int j=1; j<gestureList.size(); j++){
					writer.write(",{\"ID\":\""+gestureList.get(j).getID()+"\",\"X\":\""+gestureList.get(j).getX()+"\",\"Y\":\""+gestureList.get(j).getY()+"\"}");
					//writer.flush();
				}
				writer.write(']');
				writer.write('}');
			}
		}
		writer.write(']');
		return writer.toString(); 
	}
}
