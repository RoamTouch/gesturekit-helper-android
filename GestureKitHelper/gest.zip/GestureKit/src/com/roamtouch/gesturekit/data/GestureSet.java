package com.roamtouch.gesturekit.data;

import java.util.ArrayList;
import java.util.List;

public class GestureSet {		
	
	private String name;	
	private String gid;
	private List<Gestures> gestures = new ArrayList<Gestures>();

	
	public String getName() {
		return name;
	}		
	public void setName(String name) {
		this.name = name;
	}

	public String getGid() {
		return gid;
	}		
	public void setGid(String gid) {
		this.gid = gid;
	}
	
	public List<Gestures> getGestures(){
		return this.gestures;
	}
	
	public void setGestures(List<Gestures> gestures) {
		this.gestures = gestures;
	}
}