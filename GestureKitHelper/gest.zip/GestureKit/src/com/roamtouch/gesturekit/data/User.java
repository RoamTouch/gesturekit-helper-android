package com.roamtouch.gesturekit.data;

public class User {
	
	private String developer;
	private String application_name;
	private boolean gestureset_count;

	public User(){		
						
	}

	public String getDeveloper() {
		return developer;
	}

	public void setDeveloper(String developer) {
		this.developer = developer;
	}

	public String getApplication_name() {
		return application_name;
	}

	public void setApplication_name(String application_name) {
		this.application_name = application_name;
	}	
	
	public boolean isGestureset_count() {
		return gestureset_count;
	}

	public void setGestureset_count(boolean gestureset_count) {
		this.gestureset_count = gestureset_count;
	}
	
	
}
