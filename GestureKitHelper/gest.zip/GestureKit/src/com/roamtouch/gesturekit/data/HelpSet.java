package com.roamtouch.gesturekit.data;

import java.util.ArrayList;
import java.util.List;

public class HelpSet {	
	
	private String helptset_name;	
	private String gid;
	
	private List<Helps> helps = new ArrayList<Helps>();

	public String getName() {
		return helptset_name;
	}		
	
	public void setName(String name) {
		this.helptset_name = name;
	}

	public String getGid() {
		return gid;
	}		
	public void setGid(String gid) {
		this.gid = gid;
	}
	
	public List<Helps> getHelps(){
		return this.helps;
	}
}