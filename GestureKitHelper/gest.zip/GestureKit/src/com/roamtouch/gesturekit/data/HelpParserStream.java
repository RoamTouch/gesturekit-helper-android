package com.roamtouch.gesturekit.data;

import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.annotation.SuppressLint;
import android.util.JsonReader;

import com.roamtouch.gesturekit.communications.HelpTask.HelpListener;
import com.roamtouch.gesturekit.communications.HelpTask.onHelpProgressUpdate;

@SuppressLint("NewApi")
public class HelpParserStream {
	
	private static final String FIELD_NAME = 				"gestureset_name";
	private static final String FIELD_GID = 				"gid";
	private static final String FIELD_GESTURES = 			"gestures";
	private static final String FIELD_METHOD = 				"method";
	private static final String FIELD_IMAGE = 				"img";
	private static final String FIELD_IMG_DESCRIPTION = 	"img_description";

	@SuppressLint("NewApi")
	public Cache parse (Cache cache, String urlString, String package_name, onHelpProgressUpdate onGestureProgressUpdate, HelpListener gestureListener ) throws IOException {
		
		HelpSet helpSet = null;
		JsonReader jsonReader = null;
		
		try{
			
			URL url = new URL(urlString);
			jsonReader = new JsonReader(new InputStreamReader(url.openStream()));
			helpSet = parseHelpSet(jsonReader);
			
		} finally {
			jsonReader.close();
		}
		
		cache.putHelpSet(helpSet.getGid(), helpSet);
				
		return cache;
	}
	
	private HelpSet parseHelpSet(JsonReader jsonReader) throws IOException{
		
		HelpSet helpSet = new HelpSet();
		
		jsonReader.beginObject();
		jsonReader.nextName();
		jsonReader.beginObject();
		
		while (jsonReader.hasNext()){
			String name = jsonReader.nextName();
			if (FIELD_NAME.equals(name)) {
				helpSet.setName(jsonReader.nextString());
			}else if (FIELD_GID.equals(name)) {
				String aux = jsonReader.nextString();
				helpSet.setGid(aux);
			}else if (FIELD_GESTURES.equals(name)){				
				helpSet = parseHelp(jsonReader, helpSet);				
			}else{
				jsonReader.skipValue();
			}

		}		
		return helpSet;
	}
	
	
	private HelpSet parseHelp(JsonReader jsonReader, HelpSet helpSet) throws IOException{
				
		List<Helps> list = new ArrayList<Helps>();
		String method;
		jsonReader.beginArray();
		while (jsonReader.hasNext()) {
			jsonReader.beginObject();
			Helps helps = new Helps();
			while (jsonReader.hasNext()) {			
				String name = jsonReader.nextName();				
				if(FIELD_METHOD.equals(name)){
					method = jsonReader.nextString();
					helps.setMethod(method);					
				} else if(FIELD_IMAGE.equals(name)){
					helps.setImage(jsonReader.nextString());
				} else if(FIELD_IMG_DESCRIPTION.equals(name)){
					helps.setDescription(jsonReader.nextString());
				} else {
					jsonReader.skipValue();												
				}			
			}
			helpSet.getHelps().add(helps);		
			jsonReader.endObject();
		}		
		return helpSet;
	}
	
	
}
