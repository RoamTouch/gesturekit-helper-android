package com.roamtouch.gesturekit.data;

import java.util.Enumeration;
import java.util.Hashtable;

public class Htmls {
	
	private Hashtable<String, Html> htmls = new Hashtable<String, Html>();
	private String html_desc;
			
	public Htmls() {	
		
	}

	public void putHtml(String key, Html h) {
		this.htmls.put(key, h);
	}

	public String getHtml_desc() {
		return html_desc;
	}

	public void setHtml_desc(String html_desc) {
		this.html_desc = html_desc;
	}	
	
	public Html getHtmlByKeyLike(String key){		
		Enumeration<String> keys = htmls.keys();		
		while(keys.hasMoreElements()){
			String k = (String) keys.nextElement();
			if (k.equals(key)){			
				return htmls.get(k);
			}
		}		
		return null;		
	}
	
}
