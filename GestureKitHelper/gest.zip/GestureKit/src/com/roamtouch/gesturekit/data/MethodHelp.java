package com.roamtouch.gesturekit.data;

public class MethodHelp {
	private String method;
	private String image;
	private String description;
	
	public MethodHelp(String method, String image, String description) {
		this.method = method;
		this.image = image;
		this.description = description;
	}

	public String getMethod() {
		return method;
	}
	
	public String getImage() {
		return image;
	}
	
	public String getDescription() {
		return description;
	}
	
	public boolean equals(MethodHelp other){
		try{
			return this.method.equals(((MethodHelp)other).getMethod());
		}catch(ClassCastException e){
			return false;
		}catch(NullPointerException e){
			return false;
		}
	}
}
