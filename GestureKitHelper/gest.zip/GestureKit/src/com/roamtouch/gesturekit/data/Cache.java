package com.roamtouch.gesturekit.data;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Set;


public class Cache {
	
	private Hashtable<String, GestureSet> gestureSets = new Hashtable<String, GestureSet>();	
	private Hashtable<String, Htmls> htmls = new Hashtable<String, Htmls>();	
	private Hashtable<String, User> user = new Hashtable<String, User>();		
	private Hashtable<String, HelpSet> helpSets = new Hashtable<String, HelpSet>();
	
	private long html_update_time;
	private long gesture_update_time;	
		
	public int get_application_type() {
		return application_type;
	}

	public void set_application_type(int application_type) {
		this.application_type = application_type;
	}

	public static final int ANDROID_APPLICATION 			= 1;
	public static final int ANDROID_EYESONTV_APPLICATION 	= 2;
	
	private int application_type;

	public Cache(){	
	}	
	
	public void putHelpSet(String name, HelpSet helpSet){		
		helpSets.put(name, helpSet);
	}	
	
	public HelpSet getHelpSet(String key){
		return (HelpSet) helpSets.get(key);
	}
	
	public Set<String> getHelpSetsKeys(){
		return this.helpSets.keySet();
	}
	
	
	public void putGestureSet(String name, GestureSet gestureSet){		
		gestureSets.put(name, gestureSet);
	}	
	
	public GestureSet getGestureSet(String key){
		return (GestureSet) gestureSets.get(key);
	}
	
	public Set<String> getGestureSetsKeys(){
		return this.gestureSets.keySet();
	}
		
	public void putHtmls(String key, Htmls hs){	
		htmls.put(key, hs);	
	}
	
	public Htmls getHtmls(String key){	
		return htmls.get(key);	
	}
	
	public void putUser(String key, User u){
		user.put(key, u);
	}
	
	public User getUser(String key){	
		return user.get(key);	
	}	
	
	public long get_html_update_time() {
		return html_update_time;
	}

	public void set_html_update_time(long html_update_time) {
		this.html_update_time = html_update_time;
	}
	
	public long get_gesture_update_time() {
		return gesture_update_time;
	}

	public void set_gesture_update_time(long gesture_update_time) {
		this.gesture_update_time = gesture_update_time;
	}

}
