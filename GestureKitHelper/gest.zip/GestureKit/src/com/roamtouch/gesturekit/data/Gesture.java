package com.roamtouch.gesturekit.data;

public class Gesture {
	
   private String x;
   private String y;
   private int ID;
			
	public Gesture(){}

	public String getX() {
		return x;
	}
	public void setX(String x) {
		this.x = x;
	}

	public String getY() {
		return y;
	}
	public void setY(String y) {
		this.y = y;
	}

	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
}
