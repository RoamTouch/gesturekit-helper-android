package com.roamtouch.gesturekit.data;

public class PluginParams {

	
	public boolean GESTUREKIT_ENABLE_GRID;
	
	
	public boolean GESTUREKIT_HELPER_POPUP_MODE;
	public boolean GESTUREKIT_HELPER_ANIMATION_MODE;
	
	
	public void PluginParams(){
		
	}
}
