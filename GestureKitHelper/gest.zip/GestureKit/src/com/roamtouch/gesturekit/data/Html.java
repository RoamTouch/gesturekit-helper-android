package com.roamtouch.gesturekit.data;

public class Html {
	
	private String source;
	private String code;
			
	public Html() {}

	public String getSource() {
		return source;
	}

	public void setSource(String src) {
		this.source = src;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}	
	
}
