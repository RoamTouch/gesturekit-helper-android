package com.roamtouch.gesturekit.virtualgrid;

/**
 * Coordinate represents a location of an object in a frame coordinate system
 * 
 * @author uqbar
 *
 */
final public class Coordinate {
	private final float x;
	private final float y;

	/**
	 * Factory method to build a Coordinate object from its x,y values
	 * 
	 * @param x the x value must be grater than zero
	 * @param y the y value must be grater than zero
	 * @return a new Coordinate object initialized with x,y values
	 */
	public static Coordinate fromXY(final float x, final float y) {
		if (x <0 || y<0) {
			throw new IllegalArgumentException("Are x,y values greater equal than 0?");
		}
		return new Coordinate(x,y);
	}

	/**
	 * Represents no coordinates its origin x/y 0,0
	 */
	public static Coordinate origin() {
		return new Coordinate(0,0);
	}
	
	public Coordinate(final float x, final float y) {
		this.x = x;
		this.y = y;
	}

	public final float getX() {
		return x;
	}

	public final float getY() {
		return y;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Float.floatToIntBits(x);
		result = prime * result + Float.floatToIntBits(y);
		return result;
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final Coordinate other = (Coordinate) obj;
		if (Float.floatToIntBits(x) != Float.floatToIntBits(other.x))
			return false;
		if (Float.floatToIntBits(y) != Float.floatToIntBits(other.y))
			return false;
		return true;
	}
}
