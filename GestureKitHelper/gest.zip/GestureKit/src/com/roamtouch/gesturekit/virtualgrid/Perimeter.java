package com.roamtouch.gesturekit.virtualgrid;

import android.graphics.RectF;

/**
 * Perimeter represents an object area demarcation useful for selection
 * 
 * @author uqbar
 *
 */
final public class Perimeter {
	
	private final Coordinate leftTopEdge;
	private final float height;
	private final float width;
	RectF rect = new RectF();
	private int id;

	/**
	 * Represents a no perimeter with no width/height and coordinates in frame origin
	 */
	public static Perimeter newEmptyPerimeter() {
		return new Perimeter();
	}

	public static Perimeter newFromLeftTopEdgeAndSize(final Coordinate leftTopEdge,final int width,final int height, final int id) {
		return new Perimeter(leftTopEdge,width,height, id);
	}

	private Perimeter() {
		this(Coordinate.origin(),0,0,0);
	}

	private Perimeter(final Coordinate leftTopCoordinate, final int width,final int height, final int id) {
		this.leftTopEdge = leftTopCoordinate;
		this.height = height;
		this.width = width;	
		this.id = id;
	}	
	
	public final Coordinate getLeftTopCoordinate() {
		return leftTopEdge;
	}

	public final float getHeight() {
		return height;
	}

	public final float getWidth() {
		return width;
	}
	
	public int getId() {
		return id;
	}
	
	public boolean areCoordinatesIn(final Coordinate coordinates) {
		return areCoordinatesInPerimeter(coordinates);
	}

	private boolean areCoordinatesInPerimeter(final Coordinate coordinates) {
		return !(isCoordinateXOutOfPerimeter(coordinates) || isCoordinateYOutOfPerimeter(coordinates));
	}

	private boolean isCoordinateYOutOfPerimeter(final Coordinate coordinates) {
		return coordinates.getY() < getLeftTopCoordinate().getY() || coordinates.getY() > getLeftTopCoordinate().getY() + height;
	}

	private boolean isCoordinateXOutOfPerimeter(final Coordinate coordinates) {
		return coordinates.getX() < getLeftTopCoordinate().getX() || coordinates.getX() > getLeftTopCoordinate().getX() + width;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Float.floatToIntBits(height);
		result = prime
				* result
				+ ((leftTopEdge == null) ? 0 : leftTopEdge
						.hashCode());
		result = prime * result + Float.floatToIntBits(width);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Perimeter other = (Perimeter) obj;
		if (Float.floatToIntBits(height) != Float.floatToIntBits(other.height))
			return false;
		if (leftTopEdge == null) {
			if (other.leftTopEdge != null)
				return false;
		} else if (!leftTopEdge.equals(other.leftTopEdge))
			return false;
		if (Float.floatToIntBits(width) != Float.floatToIntBits(other.width))
			return false;
		return true;
	}
}
