package com.roamtouch.gesturekit.virtualgrid;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.roamtouch.gesturekit.GestureKit;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Point;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;

public class VirtualGridLoader {
	
	GestureKit gk;
	
	
	private ArrayList< HashMap<String, Integer> > 	dataList;	
	
	public VirtualGridLoader(GestureKit gk){
		this.gk = gk;		
	}
		
	public ArrayList< HashMap<String, Integer> > getDataList() {
		return dataList;
	}


	public void setDataList(ArrayList< HashMap<String, Integer> > dataList) {
		this.dataList = dataList;
	}
	
	public void buildGrid(int accuracy){
		
		Point size = this.gk.getScreenSize();
		int screenWidth = size.x;
		int screenHeight = size.y;
		
		int rows = screenHeight / accuracy;
		int columns = screenWidth / accuracy;
		
		int x = 0;
		int y = 0;
		int width = columns;
		int height = rows;
		
		dataList = new ArrayList< HashMap<String, Integer> >();
		
		int counter = 0;
		
		for (int j = 1; j <= accuracy; j++){
		
			for (int i = 0; i < accuracy; i++) { 		
				
				HashMap<String, Integer> hashMap = new HashMap<String, Integer>();
	    		hashMap.put("x"		, new Integer(x));
	    		hashMap.put("y"		, new Integer(y));
	    		hashMap.put("width"	, new Integer(width) );
	    		hashMap.put("height", new Integer(height));
	    		hashMap.put("second", new Integer(0));
	    		hashMap.put("id", new Integer(counter));
	    		dataList.add( hashMap );	            		
	    		         
	    		x = x + rows;	  
	    		counter++;
			} 
			
			x = 0;
			y = y + columns;
			
        }	
		
		this.setDataList(dataList);
		
	}
	
	
	
	
public VirtualGrid buildVirtualGrid(){
		
		final VirtualGrid virtualGrid = new VirtualGridImpl();
		
		ArrayList< HashMap<String, Integer> > list = this.getDataList();
		Iterator<HashMap<String, Integer>> it = list.iterator();
		
		while(it.hasNext()){
			HashMap<String, Integer> map = it.next();
			
			virtualGrid.addPerimeterBySecond(
				Perimeter.newFromLeftTopEdgeAndSize(
					Coordinate.fromXY(map.get("x"), map.get("y")), 
					map.get("width"), 
					map.get("height"),
					map.get("id")
				), 
				map.get("second")				
			);
			
		}
		
		return virtualGrid;

	}	
	
	
}
