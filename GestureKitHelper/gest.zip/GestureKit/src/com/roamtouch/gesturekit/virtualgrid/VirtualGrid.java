package com.roamtouch.gesturekit.virtualgrid;

import java.util.Map;
import java.util.Set;

/**
 * Collects frame number/ perimeter information
 * Handle the search of objects perimeters by its coordinates in a frame
 *   
 * @author uqbar
 *
 */
public interface VirtualGrid {
	VirtualGrid addPerimeterBySecond(final Perimeter perimeter,final int frameNumber);
	Perimeter getPerimeterBySecondAndCoordinate(final int frameNumber,final Coordinate coordinate);
	Map<Integer, Set<Perimeter>> getGrid();
}
