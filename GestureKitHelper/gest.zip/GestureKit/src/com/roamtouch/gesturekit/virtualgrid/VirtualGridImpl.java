package com.roamtouch.gesturekit.virtualgrid;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class VirtualGridImpl implements VirtualGrid {
	private final Map<Integer,Set<Perimeter>> grid;

	public VirtualGridImpl() {
		grid = new HashMap<Integer,Set<Perimeter>>();
	}
	
	public VirtualGrid addPerimeterBySecond(final Perimeter perimeter,final int frameNumber) {
		final Set<Perimeter> perimeters = grid.get(frameNumber) == null ? new HashSet<Perimeter>() : grid.get(frameNumber);
		perimeters.add(perimeter);
		grid.put(frameNumber,perimeters);
		return this;
	}

	public Map<Integer, Set<Perimeter>> getGrid() {
		return Collections.unmodifiableMap(grid);
	}

	public Perimeter getPerimeterBySecondAndCoordinate(final int frameNumber,final Coordinate coordinate) {
		return grid.get(frameNumber) == null ? Perimeter.newEmptyPerimeter() : searchCoordinateInPerimeters(coordinate,grid.get(frameNumber));
	}

	private Perimeter searchCoordinateInPerimeters(final Coordinate coordinate,final Set<Perimeter> perimeters) {
		Perimeter foundPerimeter = Perimeter.newEmptyPerimeter();
		for (Perimeter perimeter : perimeters) {
			if (perimeter.areCoordinatesIn(coordinate)) {
				foundPerimeter = perimeter;
				break;
			}
		}
		return foundPerimeter;
	}		
}
