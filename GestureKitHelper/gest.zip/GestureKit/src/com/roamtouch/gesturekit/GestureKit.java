package com.roamtouch.gesturekit;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Point;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnErrorListener;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings.Secure;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;

import com.roamotuch.gesturekit.plugin.ActionLauncher;
import com.roamotuch.gesturekit.plugin.GKActionInterface;
import com.roamotuch.gesturekit.plugin.GestureKitPlugins;
import com.roamotuch.gesturekit.plugin.PluginInterface;
import com.roamtouch.gesturekit.communications.AnalyticsTask;
import com.roamtouch.gesturekit.communications.AnalyticsTask.AnalyticsPostListener;
import com.roamtouch.gesturekit.communications.GestureKitService;
import com.roamtouch.gesturekit.data.GKPreferences;
import com.roamtouch.gesturekit.data.PluginParams;
import com.roamtouch.gesturekit.log.Logger;
import com.roamtouch.gesturekit.log.LoggerInterface;
import com.roamtouch.gesturekit.log.LoggerOff;
import com.roamtouch.gesturekit.virtualgrid.Coordinate;
import com.roamtouch.gesturekit.virtualgrid.Perimeter;
import com.roamtouch.gesturekit.virtualgrid.VirtualGrid;
import com.roamtouch.gesturekit.virtualgrid.VirtualGridImpl;
import com.roamtouch.gesturekit.virtualgrid.VirtualGridLoader;


public class GestureKit {
	
	private GestureKit gk;
	
	protected WindowManager.LayoutParams layoutParams;
	
	// Windows Manager WebView
	private WebView wWebView;
	private WebView lWebView;
	
	private String platform;
	
	// Analytics Async Task
	private AnalyticsTask ANALYTICS;	
	
	// LogCat log Status
	private static LoggerInterface logger = new Logger();
	
	//Cache Analytics
	private SharedPreferences.Editor analytics_editor;
	private SharedPreferences analytics;	
	private Vector<String> analytics_vector = new Vector<String>();
	
	//Cache count analytics push to server
	private SharedPreferences.Editor analytics_tracker_editor;
	private SharedPreferences analytics_tracker;		
	
	//Developer Variables
	public static String developer;	
	private String application; 
	
	// Windows Manager
	private WindowManager WM;
	
	// Javascript Bridge
	private GestureBridge pBridge;
	
	//Service URLs				
	public static String service_base_url = "http://api.gesturekit.com/";		
	
	// API Version.
	public static String api_version = "v1.1";
		
	public static String UIID;
	
	private static Activity activity;	
	
	private PluginInterface PLUGIN;
	
	private GridView gridView;
	
	//private LinearLayout gesturesView;
	
	private JSONArray help_array;
	
	public GestureKitListener listener;	

	//private Button closeHelpButton;
	private LinearLayout.LayoutParams llButton;
	
	private Hashtable<String, String> metadata = new Hashtable<String, String>();
	
	// GLOBAL VARIABLES
	private int SCALE_FACTOR = (int) 5.5; //IMPORTANT SIZE OF SCREEN
	private int BIG_TEXT_SIZE_RATIO = 42;
	
	// Help vars
	private int TextNameSize;
	
	//Device ID for Analytics
	private String device_id;
	
	//Package Name and HashCode for WM Identification.
	public static String PACKAGE_NAME;
	
	// Android Overlay
	private ViewGroup overlayGroup;
	
	// VirtualGrid
	VirtualGrid virtualgrid;
	
	// Context WM or Andoid overlay
	private int OVERLAY_CONTEXT = -1;;
	public int get_overlay_contect() { return OVERLAY_CONTEXT; }
	private static final int WINDOWS_MANAGER_CONTEXT	= 50;
	private static final int ANDROID_CONTEXT			= 51;
	
	//  Toast
	public static final int TOAST_TIMER_SHORT	= 1000;	
	public static final int TOAST_TIMER_MEDIUM	= 2500;
	public static final int TOAST_TIMER_LONG	= 5000;		
	
	
	private GestureRecognizer recognizer;	
	private boolean jacksonError = false;
	public static Context context;
	
	public static String ACTION_PLUGIN = "ACTION_PLUGIN";
	
	public static final String LOCAL_GID = "321659876561";
	//public static final String LOCAL_GID = "985306dbe587";
	
	//Screen Size
	int screenWidth = 0;
	int screenHeight = 0; 
	
	// Mode
	private boolean local;
		
	// Files URLs
	private String index;	
	private String jquery;
	private String pdollar;
	private String observer;
	
	//private GestureKitPlugins plugins;
		
	// CONSTRUCTOR OPTIONS
	
	public GestureKit(Activity mainActivity) {
		init(mainActivity, null, null, false);
	}
	
	public GestureKit(Activity mainActivity, String uiid) {
		init(mainActivity, uiid, null, false);
	}
	
	public GestureKit(Activity mainActivity, String uiid, ViewGroup paramGroup) {
		init(mainActivity, uiid, paramGroup, false);
	}
	
	public GestureKit(Activity mainActivity, String uiid, ViewGroup paramGroup, boolean local) {
		init(mainActivity, uiid, paramGroup, local);
	}
	
	// Init
	private void init (Activity mainActivity, String uiid, ViewGroup paramGroup, final boolean local) {	
		
		//GestureKit 
		this.gk = this;
		
		//platform = "Android " + Build.VERSION.SDK_INT;
		platform = "1";
		
		//  Set Activity
		this.activity = mainActivity;					
		
		// Local 
		this.local = local; 
		
		// GID
		UIID = uiid;
		
		// PLUGIN MANAGER
		new GestureKitPlugins(activity);
		
		//Package Name
		PACKAGE_NAME = this.activity.getApplicationContext().getPackageName().toString();
				
		// Only RKT can be granted to Windows Manager.
		
		if (PACKAGE_NAME.equals("com.roamtouch.rktlauncher")){
			
			// Running on Windows Maneger	
			OVERLAY_CONTEXT = WINDOWS_MANAGER_CONTEXT;
			
			// Set Windows Manager where the WebView and view are attached.
	  		WM = (WindowManager) activity.getSystemService(Context.WINDOW_SERVICE);
	  		
	  		// Drawing view and this
	  		setupLayoutParams();
		        	
        } else {
			
			// Running on App Contect.  
			OVERLAY_CONTEXT = ANDROID_CONTEXT;
			
			// Checking for View as parameter of DecoderView
			
			if (paramGroup!=null){
				
				// ViewGroup as parameter				
				this.overlayGroup = paramGroup;
						
			} else {
				
				// No Parameter we get the view from Activity				
				this.overlayGroup = (ViewGroup) this.activity.getWindow().getDecorView();
									
			}		
			
        }
				
		// Initialize object stand alone 
		if ( ! local ) {			
								
			// Set Activity view.
			
			this.local = false;		
			
			// Services from server
			activity.registerReceiver(receiver, new IntentFilter(GestureKitService.ACTION_GESTURE_KIT));
			activity.registerReceiver(receiver2, new IntentFilter(ACTION_PLUGIN));
						
			//Android			
			this.activity.runOnUiThread(new Runnable() {
				
				@Override
	            public void run() {
	               
					setWebView();
			  		setPluginTouchView();  
			  		
			  		WM = (WindowManager) activity.getSystemService(Context.WINDOW_SERVICE);
			  		getScreenSize();
			  		
					if(jacksonError){
						PLUGIN.showErrorLogo();
						return;
					}	    			
						
					Intent i = new Intent(activity, GestureKitService.class);
					activity.startService(i);			
				
	            }
	        });	
									
			// Init preferences
			GKPreferences.prefs(activity);
			
			// Set Basic Sharedpreferences for analytics.		
			this.analytics = activity.getSharedPreferences("Analytics", Context.MODE_PRIVATE);		
			this.analytics_editor = analytics.edit();
			
			// Set Basic Sharedpreferences for analytics push tracking.		
			this.analytics_tracker = activity.getSharedPreferences("AnalyticsPushCounter", Context.MODE_PRIVATE);		
			this.analytics_tracker_editor = analytics_tracker.edit();		
			
			// Device Id
			device_id = Secure.getString(mainActivity.getContentResolver(),Secure.ANDROID_ID); 
			
			try {
				if(Build.VERSION.SDK_INT <= Build.VERSION_CODES.FROYO)
					Class.forName( "com.fasterxml.jackson.core.JsonFactory" );
			} catch( ClassNotFoundException e ) {
				jacksonError = true;
				logger.LogE("Missing Jackson's jar file in your project! Download it from 'https://github.com/FasterXML/jackson-core'");
			}	
			
		} else {
			
			this.local = true;		
			
			// Stop Connection with server.			
			Intent intent = new Intent(this.activity.getApplicationContext(), GestureKitService.class);
			intent.putExtra("local","true");
			this.activity.startService(intent);
			
			// CHECK GESTURES APPS
			// Check if there are gestures, or else let the user know that needs to record. 			
		
			gestureset = GKPreferences.getString(uiid);
			
			if (!gestureset.equals("")){
				
				gesturesetObj = new JSONObject();						
				
				try {
					
					gesturesetObj =  new JSONObject ( gestureset );
					
					initWebView(this.activity.getApplicationContext());
					
				} catch (JSONException e) {
					e.printStackTrace();
				} 
				
				// Load GestureActions linked to applications
				gesture_actions = GKPreferences.getString( "gesture_actions" );				
					
				try {
								
					gesturesetActions = new JSONObject ( gesture_actions );
					
					JSONArray actions = gesturesetActions.getJSONArray("actions");
					
					for (int i=0; i<actions.length(); i++){
						
						JSONObject action = actions.getJSONObject(i);
						
						// Add the method to the plugin callback
						//GestureKitPlugins.getInstance().addAction(null, action.getString("method"), action.getString("packageName"));
						
						GestureKitPlugins.getInstance().setAction(
								(GKActionInterface) new ActionLauncher(
										activity, 
										this, 
										action.getString("method"), 
										action.getString("packageName")
										
								), action.getString("method")
						);
						
					}
					
				} catch (JSONException e) {
					e.printStackTrace();
				}		 			
													
			} else {
			
				// NO GESTURES. 
				
				if (PACKAGE_NAME.equals("com.roamtouch.rktlauncher")){
					
					// We SHOW the ProgramActivity and tell the user to record a gesture. 
					// We can reach the method with reflection without a direct call. 
					//execute_method("StartProgramActivity");
									
				} else {
					
					// We need to add a method to the library listener in order to inform there are no gestures. 
					
				} 
						
			}	
		
		}
		
		//load recognizer to track fingers
		this.recognizer = new GestureRecognizer(this);	
					
	}
	
	private void initWebView(Context context){
		
		lWebView = new WebView(activity.getApplicationContext());		
		lWebView.getSettings().setJavaScriptEnabled(true);    
		lWebView.setWebChromeClient(new WebChromeClient());	   
			
		lWebView.addJavascriptInterface(new Loader(), "loader");
		String fulljs = "javascript:(\n    function() { \n";
		fulljs += "        window.onload = function() {\n";
		fulljs += "            loader.onLoad();\n";
		fulljs += "        };\n";
		fulljs += "    })()\n";
		lWebView.loadUrl(fulljs);

		lWebView.loadDataWithBaseURL("http://www.gesturekit.com", "index.html", "text/html", "UTF-8", null);
		lWebView.setBackgroundColor(0xffff0000);
		
		pBridge = new GestureBridge(this, this.activity, this.PLUGIN);		
		lWebView.addJavascriptInterface(pBridge, "pBridge");
				
	}
	
	public void onIndexLoadCompleted() {
		Handler handler = new Handler(Looper.getMainLooper());
		handler.post(new Runnable() {
			@Override
			public void run() {				
			
				jquery = loadFile("jquery-1.9.1.min.js");				
				GKPreferences.put( UIID + "_jquery", jquery);				
				String loadJquery = GKPreferences.getString( UIID + "_jquery");				
				lWebView.loadUrl( "javascript:" + loadJquery  + ";" );
								
				pdollar = loadFile("pdollar.js");				
				GKPreferences.put( UIID + "_pdollar", pdollar);				
				String loadPdollar = GKPreferences.getString( UIID + "_pdollar");				
				lWebView.loadUrl( "javascript:" + loadPdollar  + ";" );
				
				observer = loadFile("observer.js");				
				GKPreferences.put( UIID + "_observer", observer);				
				String loadObserver = GKPreferences.getString( UIID + "_observer");						
				lWebView.loadUrl( "javascript:" + loadObserver  + ";" );	
					
				lWebView.loadUrl("javascript: loader.onComplete()");
				
			}
		});
	}
	
	public void onJavascriptCompleted() {
		Handler handler = new Handler(Looper.getMainLooper());
		handler.post(new Runnable() {
			@Override
			public void run() {		
				  Object[] params = {UIID, lWebView};	
				  LoadGesturesToPdollar loadPdollar = new LoadGesturesToPdollar();
				  loadPdollar.execute(params);			
			}			
		});
	}
	
	private String loadFile(String assetName){
		Reader reader = null;
		try{
			InputStream is = this.activity.getApplicationContext().getAssets().open(assetName);
			reader = new InputStreamReader(is);

			StringBuffer string = new StringBuffer();
			char[]buffer = new char[1024];
			int count = 0;
			while((count = reader.read(buffer)) != -1)
				string.append(new String(buffer, 0, count));
			reader.close();

			return string.toString();

		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}
	
	final class Loader {

		@JavascriptInterface
		public void onLoad() {
			onIndexLoadCompleted();
		}	
		
		@JavascriptInterface
		public void onComplete() {
			onJavascriptCompleted();
		}
	}
	
	
	public ViewGroup getOverlayGroup() {
		return overlayGroup;
	}

	
	private int getResouceId(String res, String location){
		String packa = context.getPackageName();
		return context.getResources().getIdentifier(res, location, packa); //"com.roamtouch.rktlauncherandroid");		
	}
	
	public Point getScreenSize(){	  
		
		if(android.os.Build.VERSION.SDK_INT < 10) {
		    Display display = this.gk.getWindowsManager().getDefaultDisplay();
		    screenWidth = display.getWidth();
		    screenHeight = display.getHeight();
		} else {
		    DisplayMetrics metrics = new DisplayMetrics();
		    this.gk.getWindowsManager().getDefaultDisplay().getMetrics(metrics);
		    screenWidth = metrics.widthPixels;
		    screenHeight = metrics.heightPixels;		    
		}
		
		return new Point(screenWidth, screenHeight);
		
	}
	
	public VirtualGrid getVirtualgrid() {
		return virtualgrid;
	}

	public int getScreenWidth() {
		return screenWidth;
	}

	public int getScreenHeight() {
		return screenHeight;
	}

	public void setVirtualgrid(VirtualGrid virtualgrid) {
		this.virtualgrid = virtualgrid;
	}
	private BroadcastReceiver receiver = new BroadcastReceiver() {		
		@Override
		public void onReceive(Context c, Intent i) {
			int result = i.getIntExtra(GestureKitService.RESULT, GestureKitService.RESULT_OFFLINE);
			switch (result) {
			case GestureKitService.RESULT_OFFLINE:
				if (GKPreferences.getBoolean("has_gesture_cache", false)){    						
					load_hmlt_from_cache();							
				} else {   						
					PLUGIN.showErrorLogo();		    			    		     			
				}
				break;
			case GestureKitService.RESULT_JSON_FAILED:
				PLUGIN.showErrorLogo();   				
				break;
			case GestureKitService.RESULT_JSON_SUCCESS:
				ui_call_load_hmlt_from_cache();	
				break;
			case GestureKitService.RESULT_JSON_SUCCESS_CACHE:
				ui_call_load_hmlt_from_cache();	
				
				//Analytics
				Calendar calendar = Calendar.getInstance();
				Date date = calendar.getTime();
				SimpleDateFormat format = new SimpleDateFormat("MM-dd-yyyy");
				String today = format.format(date);
				
				//always post analytics (provisory)
				//String tracked_today  = analytics_tracker.getString(today, null);
				String tracked_today = null;
				
				if( tracked_today==null || tracked_today.equals("failed")) { 
					post_analytics(today);
				} 
				break;
			default:
				break;
			}
		}
	};	
	
	public static long getTimeSinceMidnight(){		
	
		Calendar rightNow = Calendar.getInstance();
	
		// offset to add since we're not UTC
		long offset = rightNow.get(Calendar.ZONE_OFFSET) +
		    rightNow.get(Calendar.DST_OFFSET);
		long sinceMidnight = (rightNow.getTimeInMillis() + offset) %
		    (24 * 60 * 60 * 1000);
		
		return sinceMidnight;
		
	}
	
	private BroadcastReceiver receiver2 = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getStringExtra("visor_action");
            if (action != null) {
                if (action.equals("hide_visor")) {
                   ((PluginInterface)PLUGIN).setVisibility(View.INVISIBLE);
                } else if (action.equals("show_visor")){
                	((PluginInterface)PLUGIN).setVisibility(View.VISIBLE);
                }
            }
        }
    };
	
	public void onResume(){
		
		activity.registerReceiver(receiver, new IntentFilter(GestureKitService.ACTION_GESTURE_KIT));
		activity.registerReceiver(receiver2, new IntentFilter(ACTION_PLUGIN));		
		
		// Set Windows Manager where the WebView and view are attached.
  		WM = (WindowManager) activity.getSystemService(Context.WINDOW_SERVICE);
  		
  		// Drawing view and this
  		setupLayoutParams();
		
  		setWebView();
  		setPluginTouchView(); 	
		
		if(jacksonError){
			PLUGIN.showErrorLogo();
			return;
		}	    				

		Intent i = new Intent(activity, GestureKitService.class);
		activity.startService(i);
		
	}
	
	public void onPause(){
		
		activity.unregisterReceiver(receiver);
		activity.unregisterReceiver(receiver2);
		if(WM == null)
			WM = (WindowManager) activity.getSystemService(Context.WINDOW_SERVICE);
		if(PLUGIN != null && PLUGIN instanceof View)
			try{
				removeView((View)PLUGIN);
			}catch(IllegalArgumentException e){}
		if(wWebView != null)
			try{
				removeView(wWebView);
			}catch(IllegalArgumentException e){}
	}
		
	
	public void setPlugin (PluginInterface plugin) {
		
		this.PLUGIN = PLUGIN==null?plugin:PLUGIN;
		
		if (this.recognizer!=null)
			this.recognizer.setPlugin(plugin);		
		
		View viewPlugin = (View)PLUGIN;
			
		// Initialize plugins params
		PluginParams params = this.PLUGIN.getPluginParams();		
		
		//Grid enabled
		if (params.GESTUREKIT_ENABLE_GRID){			
			// Virtual Grid
			VirtualGridLoader loader = new VirtualGridLoader(this);	
			// Factor 10
			loader.buildGrid(10);
			final VirtualGrid virtualGrid = new VirtualGridImpl();
			virtualgrid = loader.buildVirtualGrid();			
		}
		
		// Init Gesture Action
		viewPlugin.setOnTouchListener(new View.OnTouchListener() {	
		    public boolean onTouch(View v, MotionEvent event) {
		    	gk.recognizer.onTouchEvent(event);
		    	//overlayGroup.dispatchTouchEvent(event);
		        return false; 
		    }
		});		
		addView(viewPlugin);		
			
	}	
	
	public void logcat_status (boolean status){
		GestureKit.logger = status ? new Logger() : new LoggerOff();
	}
	
	public PluginInterface getPlugin(){
		return this.PLUGIN;
	}
		
	private void post_analytics (final String today){
		
		ANALYTICS = new AnalyticsTask(this, UIID, device_id, platform);
		
		ANALYTICS.setAnalyticsListener(new AnalyticsPostListener(){

			@Override
			public void jsonAnalyticsSuccessfully(JSONObject result) {
				if(result == null)
					return;
				try {
					String status = result.getString("response");
					if ("Success".equals(status)){
						clear_analytics();
						analytics_tracker_editor.putString(today, "Success");
					} else {
						analytics_tracker_editor.putString(today, "Error");
					}				
					analytics_tracker_editor.commit();		
				} catch (JSONException e) {
					e.printStackTrace();
				}
			}

			@Override
			public void jsonAnalyticsFailed(Exception e) {
				analytics_tracker_editor.putString(today, "failed");
				analytics_tracker_editor.commit();		
			}
			
		});
 
		ANALYTICS.execute();
		
	}	

	
	public void ui_call_load_hmlt_from_cache() {		
		activity.runOnUiThread(new Runnable() {		 
			@Override
			public void run() {    
				load_hmlt_from_cache();		
		     }
	    });	
	}
	
	public static interface GestureKitListener {	        
    	void onGestureKitLoaded();      						
	}  
	
	public void setGestureKitListener(GestureKitListener gestureKitListener) {
       this.listener = gestureKitListener;
	}	
	
		
	/**
	 * is_device_on_line()
	 * Checks if device is oline.
	 * @return
	 */
	public boolean is_device_on_line() {
	    ConnectivityManager cm = (ConnectivityManager) activity.getSystemService(Context.CONNECTIVITY_SERVICE);
	    NetworkInfo netInfo = cm.getActiveNetworkInfo();
	    if (netInfo != null && netInfo.isConnectedOrConnecting()) {
	        return true;
	    }
	    return false;
	}			
		
	private void load_hmlt_from_cache (){
		
		String index;
		
		if (!this.local) {
			index = GKPreferences.getString(UIID + "index");
		} else {
			
			index = "index.html";
		}
		
		String mime = "text/html";
		String encoding = "utf-8";
	
		if(wWebView != null)
			wWebView.loadDataWithBaseURL("http://www.gesturekit.com", index, mime, encoding, null);

		if(this.PLUGIN != null)
			this.PLUGIN.showOkLogo();
		
		if(this.listener != null)
  			this.listener.onGestureKitLoaded();
	}	
	
	public void loadUrl (final String url){
		activity.runOnUiThread(new Runnable() {		 
			public void run() {    
				if (local)
					lWebView.loadUrl(url);
				else
					wWebView.loadUrl(url);	
		     }
        }); 
	}
	
	private void setWebView (){		
		
		wWebView = new WebView(activity.getApplicationContext());		
		wWebView.getSettings().setJavaScriptEnabled(true);		
		wWebView.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);	    
		wWebView.setWebChromeClient(new GestureChromeWebClient());	   
		wWebView.getSettings().setBuiltInZoomControls(false); 
		wWebView.setWebViewClient(new WebViewClient() {
			
			@Override
			  public boolean shouldOverrideKeyEvent(WebView view, KeyEvent event) {
					return false;		  
			  }			
			  
			  @Override
			  public void onPageStarted(WebView view, String url, Bitmap b) {
				  logger.LogV("page started: " + url);
			  }
			  
			  //Once the index.html is finished the javascript is loaded. 
			  @Override
			  public void onPageFinished(WebView view, String url) {
				  
				  if (!local){			
				  
					  logger.LogV("page finished: " + url);		
					  
					  if (url.equals("http://www.gesturekit.com/")) {				  
						  
						  jquery = GKPreferences.getString( UIID + "_jquery");					  	  	
							
						  pdollar = GKPreferences.getString( UIID + "_pdollar");
						 
						  observer = GKPreferences.getString( UIID + "_observer");
						  
					  }
										  
					  if (!jquery.equals(""))
						  wWebView.loadUrl( "javascript:" + jquery + ";" );
					  
					  if (!pdollar.equals(""))
						  wWebView.loadUrl( "javascript:" + pdollar + ";" );				
					  
					  if (!observer.equals(""))
						  wWebView.loadUrl( "javascript:" + observer + ";" );
					  
				  }	
				  			  
				  // Loads the gestures after the WebView is loaded.  
				  Object[] params = {UIID, wWebView};	
				  LoadGesturesToPdollar loadPdollar = new LoadGesturesToPdollar();
				  loadPdollar.execute(params);
				  
			  }
		});		

		wWebView.setBackgroundColor(0);
		wWebView.setBackgroundColor(Color.TRANSPARENT);
						
		wWebView.setVerticalScrollBarEnabled(false);		
		wWebView.setHorizontalScrollBarEnabled(false);		
		
		/*wWebView.setOnTouchListener(new View.OnTouchListener() {	
			
		    public boolean onTouch(View v, MotionEvent event) {
		    	//viewGroup.dispatchTouchEvent(event);
		    	GestureKit.this.recognizer.onTouchEvent(event);
		        return false;
		    }
		});*/
		
		pBridge = new GestureBridge(this, this.activity, this.PLUGIN);		
		wWebView.addJavascriptInterface(pBridge, "pBridge");		
	
	}
	
	private void setPluginTouchView (){	
		
		switch (OVERLAY_CONTEXT){
			
			case WINDOWS_MANAGER_CONTEXT:
				
				if(this.PLUGIN instanceof View){
					View view = (View)PLUGIN;
					view.setOnTouchListener(new View.OnTouchListener() {	
					    public boolean onTouch(View v, MotionEvent event) {	
					    	
					    	if(gk.recognizer!=null)
					    		gk.recognizer.onTouchEvent(event);    
					    	
					        return false; 
					    }
					});					
				}		
				
				break;				
		
			case ANDROID_CONTEXT:
				
				overlayGroup.setOnTouchListener(new View.OnTouchListener() {
	
					@Override
					public boolean onTouch(View v, MotionEvent event) {						
						if(gk.recognizer!=null)
							gk.recognizer.onTouchEvent(event);
						return false;
					}	
				   
				});		
				
				break;			
		}	
		
		
	}
	
	
	public void addView(View view){
		
		switch (OVERLAY_CONTEXT){
			
			case WINDOWS_MANAGER_CONTEXT:
				WM.addView(view, layoutParams);
				break;				
		
			case ANDROID_CONTEXT:
				overlayGroup.addView(view);
				break;			
		}	
	}	
	
	private void removeView (View view) {
		
		switch (OVERLAY_CONTEXT){
		
			case WINDOWS_MANAGER_CONTEXT:
				WM.removeView(view);
				break;				
		
			case ANDROID_CONTEXT:
				overlayGroup.addView(view);
				break;	
				
			}	
	}
	
	
	public WebView getWebView(){
		return this.wWebView;
	}
		
	private String gestureset;
	private JSONArray all_gestures;
	private JSONObject gesturesetObj;
	
	private String gesture_actions;
	private JSONObject gesturesetActions;
	
	private class LoadGesturesToPdollar extends AsyncTask<Object, Void, Object> {

		@Override
		protected Object doInBackground(Object... params) {
			
			String  uiid = (String) params[0];
        	final WebView webView = (WebView) params[1];
        	
        	all_gestures = new JSONArray();
			
			if (!local){		
				
				// If there is a separete help gesture check. 
				String add_help_array = getHelpString();
				
				if (!add_help_array.equals("")){
					
					try {
						all_gestures = addGestureToCache(uiid, add_help_array);
					} catch (JSONException e) {			
						e.printStackTrace();
					}
					
				}		
				
			} else {
				
				// load Gestures into array that is then populated into pdollar.				
				JSONArray tempArray = new JSONArray();					
				all_gestures = tempArray.put(gesturesetObj);
				
			}
			
			if(all_gestures!=null){ //gestures available
			
				activity.runOnUiThread(new Runnable() {		 
					@Override
					public void run() {   
				
						// Load observer where $p is instantiated and touch methods forwarded.
						webView.loadUrl( "javascript: loadObserver ();" );	
									
						JSONArray s_gestures = null;
						try {
							if (local) {
								s_gestures = gesturesetObj.getJSONObject("gestureset").getJSONArray("gestures");
							} else {
								s_gestures = all_gestures;
							}
						} catch (JSONException e) {							
							e.printStackTrace();
						}
						
						String numPointClouds = String.valueOf( all_gestures.length());
						
						// Set NumPointClouds from JSOn Array.
						webView.loadUrl( "javascript: setNumPointClouds ("  + s_gestures.length() + " );" );			
		
						// Set PointClouds Array.
						webView.loadUrl( "javascript: _r.LoadGestureSet ("  + s_gestures.toString() + " );" );		
						
						//if (listener!=null){
						//	listener.onGestureKitLoaded();
						//}
						
					}
					
				});
				
				// Metadata
				String meta_cache = getStringFromCache("metadata");
				meta_cache = meta_cache.replaceFirst("\\{", "");
				meta_cache = meta_cache.replaceFirst("\\}", "");
				
				String[] splitmetadata = meta_cache.split(",");	
				int length = splitmetadata.length; 
				if (length>1){			
					for (int i=0; i < splitmetadata.length ;i++){
						String[] meta = splitmetadata[i].split("=");		
						metadata.put(meta[0].trim(), meta[1].trim());			
					}	
				}
			} else {
				// Nothing loaded not working showing warning.
				PLUGIN.showErrorLogo();		
			}
			
			return null;
		}

		
	}
		
	
	// Method to add a gesture to the a
	
	public JSONArray addGestureToCache(String uiid, String add_array) throws JSONException{
		
		//Joing back-end JSON with HELP JSON. 
		String all_gestures_string;		
		
		
		JSONArray all_gestures = null; 
		try {
			 all_gestures_string = GKPreferences.getString(uiid);
			 all_gestures = new JSONArray(all_gestures_string);
		} catch (JSONException e) {			
			e.printStackTrace();
		}
		
	
		JSONArray gestures_add_array = null;
		
		try {
			gestures_add_array = new JSONArray(add_array);			
			Map<String, String> icons = new HashMap<String, String>();
			for(int i = 0; i < gestures_add_array.length(); i++){
				  JSONObject gesture = gestures_add_array.getJSONObject(i);
				  icons.put(gesture.getString("name"), gesture.getString("image"));
			}
			
			if (this.PLUGIN!=null) 
				this.PLUGIN.onGesturesIcon(this, icons);
			
		} catch (JSONException e) {			
			e.printStackTrace();
		}
		
		return all_gestures;
		
	}
	
	
		
	/**
	 * Sets the Layout Parameters to run on Windows Manager correctly. 
	 */
	private void setupLayoutParams() {			
		
		layoutParams = new WindowManager.LayoutParams(
				WindowManager.LayoutParams.MATCH_PARENT, 
				WindowManager.LayoutParams.MATCH_PARENT,
				WindowManager.LayoutParams.TYPE_PHONE, 						
				WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
				| WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH 
				| WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED, //NEEDED FOR onSurfaceTextureAvailable inflation. 
				PixelFormat.TRANSLUCENT);	
		
		layoutParams.gravity = Gravity.CENTER; 

	}
	
	public class GestureChromeWebClient extends WebChromeClient implements 	OnCompletionListener, OnErrorListener {
		public boolean onError(MediaPlayer arg0, int arg1, int arg2) {
			return false;
		}
		
		public void onCompletion(MediaPlayer arg0) {}
	}
	
	//Developer Methods
	public String getDeveloper() {
		return developer;
	}


	public void setDeveloper(String developer2) {
		developer = developer2;
	}

	public String getApplication() {
		return application;
	}

	public void setApplication(String application) {
		this.application = application;
	}
	
	private Method method = null;
		
	public void executeMethod(String functionName){				
		
		// Initialize plugins params
		PluginParams params = this.PLUGIN.getPluginParams();	
		
		// LAB Grid enabled 
		// DO NOT USE!!
		if (params.GESTUREKIT_ENABLE_GRID){		
			Vector<String> region_path =  this.recognizer.get_region_path();		
			String [] strconverted = region_path.toArray(new String[region_path.size()]);	
			Vector stored = new Vector(); 						
			List similarities = new ArrayList();		
			if (region_path.size()<stored.size()){			
			}		
			for(int i = 0; i < Math.max(region_path.size(), stored.size()); i++){				
				if(i < region_path.size() && i< stored.size()){			
					if (region_path.get(i) == stored.get(i)) {				
				       similarities.add(region_path.get(i));			       
					}				
				}
			}
		}
		
		logger.LogV("Method Recognized: " + functionName);		
		//JSONArray dataset_array = new JSONArray();
		
		GKActionInterface action = GestureKitPlugins.getInstance().getActionByName(functionName);
		
		if (functionName.equals("CLEAR_VISOR")){
			PLUGIN.showOkLogo();			
			if (action != null)
			{
				action.onGestureRecognized("CLEAR_VISOR");
			}
			
		} else {
			PLUGIN.showOkLogo();
			if (action != null)
				if (this.metadata.containsKey(functionName))			
					action.onGestureRecognized(this.metadata.get(functionName));
				else
					action.onGestureRecognized(functionName);
			else
				execute_method (functionName);
		}
				
    }

	private void execute_method (String functionName) {
		
		String metaParameter = null;
		if (this.metadata.containsKey(functionName))			
			metaParameter = this.metadata.get(functionName);
		
		String name = activity.getClass().getName();				
		Class<?> c = null;
		try {
			c = Class.forName( name );
		} catch (ClassNotFoundException e2) {			
			e2.printStackTrace();
		}		

        method = null;
        try {
        	if(metaParameter == null)
        		method = c.getDeclaredMethod(functionName);
        	else
        		method = c.getDeclaredMethod(functionName, String.class);
        } catch (Exception e) {        	
        	PLUGIN.showErrorLogo();    
        	logger.LogV("WARNING: The method '" + functionName + (metaParameter==null?"()":"(String)") + "' was not found. Please add your method to the activity.");
        	e.printStackTrace();
        }
        
        if (method!=null){
	        try {
	        	
	        	if(metaParameter == null)
	        		method.invoke(activity);
	        	else
	        		method.invoke(activity, metaParameter);
	        	
	        	//Store to Analytics.
	        	add_gesture_to_analytics_cache(functionName);	   
	        	
			} catch (IllegalArgumentException e) {			
				e.printStackTrace();
			} catch (IllegalAccessException e) {			
				e.printStackTrace();
			} catch (InvocationTargetException e) {			
				e.printStackTrace();
			}
        }
	}
	
	Handler handler = new Handler();
	
	public void flash_plugin_image (final int image){
		activity.runOnUiThread(new Runnable() {		 
			@Override
			public void run() {   
				// Nothing loaded not working showing warning.
		    	//touchView.setDraw(image);	   	
		    	final Runnable r = new Runnable()
		    	{
		    	    public void run() 
		    	    {
				    	//touchView.setDraw(MultiPaintView.VISOR_LOGO);	
				    	PLUGIN.showErrorLogo();
		    	        handler.removeCallbacks(this);
		    	    }
		    	};
		    	handler.postDelayed(r, 3000);
		     }
        });	   	
	}
	
	public String getStringFromCache(String key){
		String key_uiid = UIID + "_" + key;
		return GKPreferences.getString(key_uiid);
	}
	
	public void clear_cache (){
		GKPreferences.clear_cache();
	}
	
	public SharedPreferences getAnalytics() {
		return analytics;
	}	
	
	private void add_gesture_to_analytics_cache(String recognized_method){		
		int count_method = analytics.getInt(recognized_method, -1);
		if (count_method==-1){			
			add_data_to_analytics(recognized_method, 1);
		} else if (count_method>-1){
			count_method++;
			add_data_to_analytics(recognized_method, count_method);
		}		
		analytics_editor.commit();			
	}
	
	public void add_data_to_analytics (String key, Object value) {
		this.analytics_vector.add(key);		
		if (value instanceof Integer){ 	
			int i = (Integer) value;
			analytics_editor.putInt(key, i);
		} else if (value instanceof String){ 
			analytics_editor.putString(key, value.toString());
		}
	}
	
	public void clear_analytics (){
		for (int i=0; i<this.analytics_vector.size(); i++){
			this.analytics_editor.remove((String) this.analytics_vector.get(i));
		}		
		this.analytics_editor.commit();
	}
	
	public void setAnalytics(SharedPreferences analytics) {
		this.analytics = analytics;
	}
	
	public int get_SCALE_FACTOR() {
		return SCALE_FACTOR;
	}

	public void set_SCALE_FACTOR(int sCALE_FACTOR) {
		SCALE_FACTOR = sCALE_FACTOR;
	}

	public int get_BIG_TEXT_SIZE_RATIO() {
		return BIG_TEXT_SIZE_RATIO;
	}

	public void set_BIG_TEXT_SIZE_RATIO(int bIG_TEXT_SIZE_RATIO) {
		BIG_TEXT_SIZE_RATIO = bIG_TEXT_SIZE_RATIO;
	}
	

	public int getTextNameSize() {
		return TextNameSize;
	}

	public void setTextNameSize(int textNameSize) {
		TextNameSize = textNameSize;
	}
	
	private int color = 0xFF55555;
	
	public int getColor() {
		return color;
	}

	public void setColor(int color) {
		this.color = color;
	}

	private int light_color = 0xB3EAFF;	

	public int getLight_color() {
		return light_color;
	}

	public void setLight_color(int light_color) {
		this.light_color = light_color;
	}
	
	private int dark_color = 0x2A97BF;

	public int getDark_color() {
		return dark_color;
	}

	public void setDark_color(int dark_color) {
		this.dark_color = dark_color;
	}
	
	public static LoggerInterface getLogger(){
		return logger;
	}
	
	public String getHelpString(){
		return GKPreferences.getString( UIID + "_help_array");
	}
	
	public WindowManager getWindowsManager() {
		return WM;
	}
	
	public WindowManager.LayoutParams getLayoutParams() {
		return layoutParams;
	}
	
	public static String get_service_base_url() {
		return service_base_url;
	}
	
	public static String get_api_version() {
		return api_version;
	}
	public static String getActiveUIID() {
		return UIID;
	}
	public static String getUIID() {
		return UIID;
	}

}
