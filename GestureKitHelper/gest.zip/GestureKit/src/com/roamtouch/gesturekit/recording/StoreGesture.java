package com.roamtouch.gesturekit.recording;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.roamotuch.gesturekit.plugin.GestureKitPlugins;
import com.roamtouch.gesturekit.data.GKPoint;
import com.roamtouch.gesturekit.data.GKPreferences;

import android.graphics.PointF;
import android.os.AsyncTask;
import android.util.SparseArray;

public class StoreGesture extends AsyncTask<Object, Void, Boolean> {
	String mPackageName;
	
	public StoreGesture(String packageName)
	{
		super();
		mPackageName = packageName;
	}
	
    @Override
    protected Boolean doInBackground(Object ... params) {	        	
    	String m = (String) params[0];
    	SparseArray<List<PointF>> toStore = (SparseArray<List<PointF>>) params[1];
    	storeGestureSet(m, toStore); 
    	String image = (String) params[2];
    	storeHelp(m, image);
        return true;
    }	     

	protected void onPostExecute(boolean result) {}
    @Override
    protected void onPreExecute() {}
    @Override
    protected void onProgressUpdate(Void... values) {}
    
    private void storeGestureSet(String m, SparseArray<List<PointF>> mFinishedPoints){			
		
		try {
			// NEW GESTURE		
			JSONObject n_gesturesdata = new JSONObject();
			n_gesturesdata.put("method", m);
			n_gesturesdata.put("metadata", "0");
			n_gesturesdata.put("color", "#ffffff");	
			n_gesturesdata.put("packageName", mPackageName);	
			n_gesturesdata.put("gesture", new JSONArray());
			
			JSONArray gesture = n_gesturesdata.getJSONArray("gesture");
			gesture = collectGestures(mFinishedPoints, n_gesturesdata);
			
			// STORED GESTURES
			String s_storedraw = GKPreferences.getString( "321659876561" );									
			JSONObject s_all = new JSONObject(s_storedraw);
			JSONArray s_gestures = s_all.getJSONObject("gestureset").getJSONArray("gestures");				
			s_gestures.put(n_gesturesdata);						
			
			// COMMIT 
			GKPreferences.put("321659876561", s_all.toString());		
										
		} catch (JSONException e) {
			e.printStackTrace();
		}				
	}
	
	private void storeHelp(String m, String image){
		try {			
			// NEW HELP				
			JSONObject n_helpdata = new JSONObject();				
			n_helpdata.put("method", m);				
			n_helpdata.put("image", image);
			n_helpdata.put("img_description", m);	
			n_helpdata.put("packageName", mPackageName);	
							
			// STORED GESTURES
			String s_storedhelp = GKPreferences.getString( "321659876561_help_array" );										
			JSONObject s_all = new JSONObject(s_storedhelp);
			JSONArray s_gestures = s_all.getJSONObject("gestureset").getJSONArray("gestures");				
			s_gestures.put(n_helpdata);	
			
			// COMMIT
			GKPreferences.put("321659876561_help_array", s_all.toString());							
		} catch (JSONException e) {
			e.printStackTrace();
		}		
	}

	private JSONArray collectGestures(SparseArray<List<PointF>> mPoints, JSONObject gestures) throws JSONException{
		
		JSONArray coords = gestures.getJSONArray("gesture");			
	
		GKPoint[] temp = GKPoint.getGKPoints(mPoints);
		GKPoint[] processed = PointProcessor.ProcessPoints(temp);
	
		int length = processed.length;		
		for (int i=0; i < length; i++){			
			JSONObject g = new JSONObject();
			g.put("ID", processed[i].getStrokeId());
			g.put("X", processed[i].getX());
			g.put("Y", processed[i].getY());
			coords.put(g);					
		}			
		return coords;
	}
	
}		