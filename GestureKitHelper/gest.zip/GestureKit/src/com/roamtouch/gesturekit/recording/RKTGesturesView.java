package com.roamtouch.gesturekit.recording;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Path.Direction;
import android.graphics.PointF;
import android.graphics.Rect;
import android.util.Base64;
import android.util.Log;
import android.util.SparseArray;
import android.view.MotionEvent;
import android.view.View;

import com.roamtouch.gesturekit.data.GKPoint;
import com.roamtouch.gesturekit.data.GKPreferences;

public class RKTGesturesView extends View
{
	RKTGestureViewListener	listener;
	
	private static final int SIZE = 5;
	private Paint mPaint;
	private int mStrokeId;
	Path mTouchPath;

	SparseArray<List<PointF>> mActivePointers;
	SparseArray<List<PointF>> mFinishedPoints;
	
	public Context mContext;
	
	Path mLoaded = new Path();
		
	String method;
	String packageName;
	String guid;
	Intent programIntent;

	public RKTGesturesView(Context context, Intent intent)
	{
		super(context);
		
		 programIntent = intent;
			method = programIntent.getStringExtra("name");
			packageName = programIntent.getStringExtra("packageName");
			guid = programIntent.getStringExtra("UIID"); 
						
			init();
	}
	
	private void init(){
		
		mActivePointers = new SparseArray<List<PointF>>();
		mFinishedPoints = new SparseArray<List<PointF>>();

		mPaint = new Paint();
		// set painter color to a color you like
		mPaint.setColor(Color.CYAN);
		mPaint.setStyle(Paint.Style.STROKE);
		mPaint.setStrokeWidth(SIZE);
		mStrokeId = 0;
		mTouchPath = new Path();		
	}

	public void setListener(RKTGestureViewListener listener)
	{
		this.listener = listener;
	}

	int	count;

	@Override
	public boolean onTouchEvent(MotionEvent event)
	{

		// get pointer index from the event object
		int pointerIndex = event.getActionIndex();

		// get pointer ID
		int pointerId = event.getPointerId(pointerIndex);

		// get masked (not specific to a pointer) action
		int maskedAction = event.getActionMasked();

		switch (maskedAction)
		{

			case MotionEvent.ACTION_DOWN:
			case MotionEvent.ACTION_POINTER_DOWN:
			{
				// We have a new pointer. Lets add it to the list of pointers
				try
				{
					PointF f = new PointF();
					f.x = event.getX(pointerIndex);
					f.y = event.getY(pointerIndex);

					int index = mActivePointers.indexOfKey(pointerId);
					if (index < 0)
					{
						ArrayList<PointF> points = new ArrayList<PointF>();
						points.add(f);
						mActivePointers.put(pointerId, points);
					}
					else
					{
						ArrayList<PointF> points = (ArrayList<PointF>) mActivePointers.get(pointerId);
						points.add(new PointF(event.getX(), event.getY()));
						mActivePointers.put(pointerId, points);
					}
				}
				catch (Exception e)
				{
					Log.v("actiondown", "Exception on actiondown: " + e.getMessage());
				}
				break;
			}
			case MotionEvent.ACTION_MOVE:
			{ // a pointer was moved
				try
				{
					for (int size = event.getPointerCount(), i = 0; i < size; i++)
					{
						int pIndex = event.getPointerId(i);

						PointF p = new PointF(event.getX(pIndex), event.getY(pIndex));
						ArrayList<PointF> points = (ArrayList<PointF>) mActivePointers.get(pIndex);
						points.add(p);

						mActivePointers.put(pIndex, points);
					}
				}
				catch (Exception e)
				{
					Log.v("actionmove", "Exception on actionmove: " + e.getMessage());
				}
				break;
			}
			case MotionEvent.ACTION_UP:
			case MotionEvent.ACTION_POINTER_UP:
			case MotionEvent.ACTION_CANCEL:
				try
				{
					ArrayList<PointF> points = (ArrayList<PointF>) mActivePointers.get(pointerId);
					if (points != null && points.size() > 0) mFinishedPoints.put(mStrokeId++, points);
					mActivePointers.remove(pointerId);

					// SOTRE GESTURE TO GestureKit Cache.

					Bitmap bitmap = GetBitmap();

					ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
					bitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
					byte[] byteArray = byteArrayOutputStream.toByteArray();

					String image = Base64.encodeToString(byteArray, Base64.DEFAULT);

					// Starting async to store not to stop ongoing interaction.
					StoreGesture store = new StoreGesture(packageName);
					Object[] params = { method, mFinishedPoints, image };
					store.execute(params);

					// RECORD THEREE TIMES THEN GO BACK.

					count = GKPreferences.getInt("count_gesture_records");

					if (listener != null)
					{
						listener.didRecordGesture(count);
					}

					Log.v("GK", "count: " + count);

					if (count > 1)
					{

						// STORED ACTIONS

						JSONObject actions = new JSONObject();
						actions.put("method", method);
						actions.put("packageName", packageName);

						String storedactions = GKPreferences.getString("gesture_actions");
						JSONObject all_actions = new JSONObject(storedactions);
						JSONArray s_actions = all_actions.getJSONArray("actions");
						s_actions.put(actions);

						// COMMIT TO ACTION
						GKPreferences.put("gesture_actions", all_actions.toString());

						// Go back to Programs list

						GKPreferences.put("count_gesture_records", 0);

					}
					else
					{

						GKPreferences.put("count_gesture_records", count + 1);

					}

				}
				catch (Exception e)
				{
					Log.v("actionup", "Exception on actionup: " + e.getMessage());
				}
				break;
		}
		invalidate();

		return true;
	}

	@SuppressLint("DrawAllocation")
	@Override
	protected void onDraw(Canvas canvas)
	{
		try
		{
			super.onDraw(canvas);
			// reset the path to draw the new one
			mTouchPath.reset();

			// we add to the path the active paths and the finished ones as well
			// we use a single path as it's the most effective way
			mTouchPath = getPath(mTouchPath, mActivePointers);
			mTouchPath = getPath(mTouchPath, mFinishedPoints);

			ArrayList<GKPoint> result = GKPoint.getGKPointsList(mActivePointers);
			result.addAll(GKPoint.getGKPointsList(mFinishedPoints));

			if (result.size() > 0)
			{
				Rect bounding = PointProcessor.GetBoundingArea(result);
				Rect location = PointProcessor.GetGestureLocation(result, 3, this.getHeight(), this.getWidth());
				mTouchPath.addRect(bounding.left, bounding.top, bounding.right, bounding.bottom, Direction.CW);
				mTouchPath.addRect(location.left, location.top, location.right, location.bottom, Direction.CW);
			}

			// we draw the path
			canvas.drawPath(mTouchPath, mPaint);

		}
		catch (Exception e)
		{
			Log.v("draw", "Exception on draw: " + e.getMessage());
		}
	}

	Path getPath(Path path, SparseArray<List<PointF>> pointMap)
	{
		int key = 0;
		for (int i = 0; i < pointMap.size(); i++)
		{
			key = pointMap.keyAt(i);
			// get the object by the key.
			ArrayList<PointF> points = (ArrayList<PointF>) pointMap.get(key);
			path = getPath(path, points);
		}
		return path;
	}

	Path getPath(Path path, ArrayList<PointF> points)
	{
		if (points != null && points.size() > 1)
		{
			int size = points.size();
			float x = points.get(0).x, y = points.get(0).y;

			path.moveTo(x, y);
			path.addCircle(x, y, SIZE, Direction.CW);
			path.addCircle(x, y, SIZE / (float) 2, Direction.CW);

			for (int i = 1; i < points.size(); i++)
				path.lineTo(points.get(i).x, points.get(i).y);

			if (size > 1)
			{
				x = points.get(size - 1).x;
				y = points.get(size - 1).y;
				path.addCircle(x, y, SIZE, Direction.CW);
				path.addCircle(x, y, SIZE / (float) 2, Direction.CW);

			}
		}
		return path;
	}

	Path getPathFromGKPoints(Path path, ArrayList<GKPoint> points)
	{
		if (points != null && points.size() > 1)
		{
			int size = points.size();
			float x = (float) points.get(0).getX(), y = (float) points.get(0).getY();

			path.moveTo(x, y);
			path.addCircle(x, y, SIZE, Direction.CW);
			path.addCircle(x, y, SIZE / (float) 2, Direction.CW);

			for (int i = 1; i < points.size(); i++)
				path.lineTo((float) points.get(i).getX(), (float) points.get(i).getY());

			if (size > 1)
			{
				x = (float) points.get(size - 1).getX();
				y = (float) points.get(size - 1).getY();
				path.addCircle(x, y, SIZE, Direction.CW);
				path.addCircle(x, y, SIZE / (float) 2, Direction.CW);
			}
		}
		return path;
	}

	public Bitmap GetBitmap()
	{
		Bitmap bitmap = Bitmap.createBitmap(this.getWidth(), this.getHeight(), Bitmap.Config.ARGB_8888);
		Canvas canvas = new Canvas(bitmap);

		// we add to the path the active paths and the finished ones as well
		// we use a single path as it's the most effective way
		Path result = new Path();
		result = getPath(result, mActivePointers);
		result = getPath(result, mFinishedPoints);

		// we draw the path
		canvas.drawPath(result, mPaint);
		return bitmap;
	}

	public void Clear()
	{
		init();
		invalidate();
	}
}
