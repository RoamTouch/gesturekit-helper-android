package com.roamtouch.gesturekit.recording;

import java.util.ArrayList;

import android.graphics.Rect;

import com.roamtouch.gesturekit.data.GKPoint;

/**
 * @author Ionut
 * A class containing static methods
 * for processing gk points.
 */
public class PointProcessor {

	public static int SAMPLING_RESOLUTION = 32;

	public static GKPoint[] ProcessPoints(GKPoint[] points)
	{
		GKPoint[] result = Scale(points);	
		result = TranslateTo(result, Centroid(result));
		result = Resample(result, SAMPLING_RESOLUTION);
		return result;
	}

	public static GKPoint[] Scale(GKPoint[] points)
	{
		double minx = Double.MAX_VALUE, miny = Double.MAX_VALUE, 
				maxx = Double.MIN_VALUE, maxy = Double.MIN_VALUE;

		for(int i=0;i<points.length;i++)
		{
			if (minx > points[i].getX()) minx = points[i].getX();
			if (miny > points[i].getY()) miny = points[i].getY();
			if (maxx < points[i].getX()) maxx = points[i].getX();
			if (maxy < points[i].getY()) maxy = points[i].getY();	
		}

		GKPoint[] newPoints = new GKPoint[points.length];
		double scale= Math.max(maxx - minx, maxy - miny);
		for(int i=0; i < points.length; i++)
			newPoints[i] = new GKPoint(
					(points[i].getX() - minx) / scale, 
					(points[i].getY() - miny) / scale, 
					points[i].getStrokeId()
					);

		return newPoints;
	}

	public static GKPoint[] TranslateTo(GKPoint[] points, GKPoint p)
	{
		GKPoint[] newPoints = new GKPoint[points.length];
		for (int i = 0; i < points.length; i++)
			newPoints[i] = new GKPoint(points[i].getX() - p.getX(), 
					points[i].getY() - p.getY(), 
					points[i].getStrokeId());
		return newPoints;
	}

	public static GKPoint Centroid(GKPoint[] points)
	{
		float cx = 0, cy = 0;
		for (int i = 0; i < points.length; i++)
		{
			cx += points[i].getX();
			cy += points[i].getY();
		}
		return new GKPoint(cx / points.length, cy / points.length, 0);
	}

	public static GKPoint[] Resample(GKPoint[] points, int n)
	{
		GKPoint[] newPoints = new GKPoint[n];
		newPoints[0] = new GKPoint(points[0].getX(), points[0].getY(), points[0].getStrokeId());
		int numPoints = 1;

		double I = PathLength(points) / (n - 1); // computes interval length
		double D = 0;
		for (int i = 1; i < points.length; i++)
		{
			if (points[i].getStrokeId() == points[i - 1].getStrokeId())
			{
				double d = EuclideanDistance(points[i - 1], points[i]);
				if (D + d >= I)
				{
					GKPoint firstPoint = points[i - 1];
					while (D + d >= I)
					{
						// add interpolated point
						double t = Math.min(Math.max((I - D) / d, 0.0f), 1.0f);
						if (Double.isNaN(t)) t = 0.5f;
						newPoints[numPoints++] = new GKPoint(
								(1.0f - t) * firstPoint.getX() + t * points[i].getX(),
								(1.0f - t) * firstPoint.getY() + t * points[i].getY(),
								points[i].getStrokeId()
								);

						// update partial length
						d = D + d - I;
						D = 0;
						firstPoint = newPoints[numPoints - 1];
					}
					D = d;
				}
				else D += d;
			}
		}
		// sometimes we fall a rounding-error short of adding the last point, so add it if so
		if (numPoints == n - 1) 
			newPoints[numPoints++] = new GKPoint(points[points.length - 1].getX(), 
					points[points.length - 1].getY(), 
					points[points.length - 1].getStrokeId());

		return newPoints;
	}

	public static double PathLength(GKPoint[] points)
	{
		float length = 0;
		for (int i = 1; i < points.length; i++)
			if (points[i].getStrokeId() == points[i - 1].getStrokeId())
				length += EuclideanDistance(points[i - 1], points[i]);
		return length;
	}

	public static double EuclideanDistance(GKPoint pointA, GKPoint pointB)
	{
		return Math.sqrt((pointA.getX() - pointB.getX())*(pointA.getX() - pointB.getX()) + 
				(pointA.getY() - pointB.getY())*(pointA.getY() - pointB.getY()));
	}

	/**
	 * Gets the center of mass for the given points.
	 */
	public static GKPoint GetCenterOfMass(ArrayList<GKPoint> points)
	{
		GKPoint result = new GKPoint(0, 0, 0);
		if(points == null || points.size() == 0)
			return result;
		int size = points.size();
		for(int i=0; i<size; i++)
		{
			result.setX(result.getX() + points.get(i).getX());
			result.setY(result.getY() + points.get(i).getY());
		}
		result.setX(result.getX()/size);
		result.setY(result.getY()/size);    

		return result;
	}

	/*
	 * This gets the bounding area of the given points as a rectangular.
	 * We work with integer coordinates in this even if the GKPoints coordinates are double.
	 */	
	public static Rect GetBoundingArea(ArrayList<GKPoint> points)
	{
		if(points == null || points.size() == 0)
			return new Rect();

		int left = Integer.MAX_VALUE, right = Integer.MIN_VALUE, top = Integer.MIN_VALUE, bottom = Integer.MAX_VALUE;
		for(int i=0; i<points.size(); i++)
		{
			int x = (int)points.get(i).getX();
			int y = (int)points.get(i).getY();
			if(x < left)
				left = x;
			if(x > right)
				right = x;
			if(y < bottom)
				bottom = y;
			if(y > top)
				top = y;
		}

		return new Rect(left, top, right, bottom);
	}
	/*
	 * Depending on the gridCount returns the location of the provided gesture. 
	 * The grid count gives us the number of columns and rows for the screen. 
	 * For now we consider that the number of rows is the same as the one of columns.
	 * In the future we might consider different counts per dimension.
	 * 
	 */
	public static Rect GetGestureLocation(ArrayList<GKPoint> points, int gridCount, 
			int screenHeight, int screenWidth)
	{
		if(gridCount <= 0)
			return new Rect();
		
		int wUnit = screenWidth/gridCount;
		int hUnit = screenHeight/gridCount;
		
		GKPoint center = GetCenterOfMass(points);
		int x = (int)center.getX();
		int y = (int)center.getY();
		int gridColumn = x/wUnit;
		int gridRow = y/hUnit;
		
		return new Rect(gridColumn * wUnit, gridRow * hUnit, (gridColumn + 1) * wUnit, (gridRow + 1) * hUnit);
	}
}
