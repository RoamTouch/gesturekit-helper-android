package com.roamtouch.gesturekit.recording;

public interface RKTGestureViewListener
{
	public void didRecordGesture(int timesRecordedBefore);
	public void didClearCanvas();
}
