package com.roamtouch.gesturekit;

import java.util.Vector;

import com.roamotuch.gesturekit.plugin.PluginInterface;
import com.roamtouch.gesturekit.data.PluginParams;
import com.roamtouch.gesturekit.virtualgrid.Coordinate;
import com.roamtouch.gesturekit.virtualgrid.Perimeter;
import com.roamtouch.gesturekit.virtualgrid.VirtualGrid;

import java.util.Arrays;
import java.util.Comparator;

import android.os.AsyncTask;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

public class GestureRecognizer {
	private GestureKit gk;
	private boolean move;
	
	private PluginInterface PLUGIN;
	
	Vector<String> region_path = new Vector<String>();
	
	StoreRegions store_regions;

	public GestureRecognizer(GestureKit gk){
		this.gk = gk;	
	}

	@SuppressWarnings("deprecation")
	public boolean onTouchEvent(MotionEvent event){
		
		int action = event.getActionMasked(); // event type 
		int actionIndex = event.getActionIndex(); // pointer (i.e., finger)
    	  
		if ( action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_1_DOWN){
			move = true;	          
			this.gk.loadUrl("javascript: startPoint(" + ((int) event.getX(actionIndex)) + "," + ((int) event.getY(actionIndex)) + "," + actionIndex + ");");
		} 
		else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_POINTER_1_UP)
		{		    	 		    	
			this.gk.loadUrl("javascript: endPoint();");
		} 
		else 
		{	
			if (move){ 
				for(int i=0; i<event.getPointerCount(); i++){
					int pointerID = event.getPointerId(i);
					
					int pointerIndex = event.findPointerIndex(pointerID);
					
					int x = ((int) event.getX(pointerIndex));
					int y = ((int) event.getY(pointerIndex)) ;
					
					//this.gk.loadUrl("javascript: movePoint(" + x + "," + y + "," + pointerIndex + ");" );
					
					this.gk.loadUrl("javascript: movePoint(" + ((int) event.getX(pointerIndex)) + "," + ((int) event.getY(pointerIndex))  + "," + pointerIndex + ");");
					
					// Initialize plugins params if exists plugin
					if (this.gk.getPlugin()!=null){					
						PluginParams params = this.PLUGIN.getPluginParams();					
						//Grid enabled
						if (params.GESTUREKIT_ENABLE_GRID){	
							StoreRegions store = new StoreRegions();					
							String[] param = {Float.toString(x),Float.toString(y)};					
							store.execute((String[]) param);	
						}						
					}
					
				}
			}
		} 

		if (action == MotionEvent.ACTION_UP){
			move = false;
		}
		
		
		if( this.PLUGIN != null && this.PLUGIN instanceof View){
			this.PLUGIN.proccessTouchEvent(event);
		}	

		return false; 
	}
	
	public Vector<String> get_region_path() {
		return region_path;
	}

	public void setPlugin(PluginInterface plugin){
		this.PLUGIN = plugin;
	}
	
	private class StoreRegions extends AsyncTask<String, Void, String> {      

		@Override
		protected String doInBackground(String... params) {
			
			float x = Float.parseFloat(params[0]);
        	float y = Float.parseFloat(params[1]);
        	
        	// VirtualGrid
			Coordinate coordinate = new Coordinate(x,y);
			
			Perimeter per = gk.getVirtualgrid().getPerimeterBySecondAndCoordinate(0, coordinate);
							
			if (per.areCoordinatesIn(coordinate)){		
				
				String id =  String.valueOf(per.getId());		
				Log.v("GK","id :: "+id);				
				region_path.add(id);			
				String p = region_path.toString();	
				
			}	
			
			return null;
		}
		
		 @Override
	     protected void onPreExecute() { 
			 
		 }

	     @Override
	     protected void onProgressUpdate(Void... values) {}
    }
	
	
}
