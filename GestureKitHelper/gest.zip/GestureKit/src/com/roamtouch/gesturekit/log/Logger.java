package com.roamtouch.gesturekit.log;

import android.util.Log;

import com.roamtouch.gesturekit.GestureKit;

public class Logger implements LoggerInterface {
	private final String TAG = GestureKit.class.getName();

	@Override
	public void LogV(String message) {
		Log.v(TAG, message);
	}

	@Override
	public void LogI(String message) {
		Log.i(TAG, message);
	}

	@Override
	public void LogD(String message) {
		Log.d(TAG, message);
	}

	@Override
	public void LogW(String message) {
		Log.w(TAG, message);
	}

	@Override
	public void LogE(String message) {
		Log.e(TAG, message);
	}

	@Override
	public void LogV(String message, Throwable t) {
		Log.v(TAG, message, t);
	}

	@Override
	public void LogI(String message, Throwable t) {
		Log.i(TAG, message, t);
	}

	@Override
	public void LogD(String message, Throwable t) {
		Log.d(TAG, message, t);
	}

	@Override
	public void LogW(String message, Throwable t) {
		Log.w(TAG, message, t);
	}

	@Override
	public void LogE(String message, Throwable t) {
		Log.e(TAG, message, t);
	}

}
