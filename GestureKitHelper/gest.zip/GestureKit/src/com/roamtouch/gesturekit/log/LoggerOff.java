package com.roamtouch.gesturekit.log;

public class LoggerOff implements LoggerInterface {

	@Override
	public void LogV(String message) {}

	@Override
	public void LogI(String message) {}

	@Override
	public void LogD(String message) {}

	@Override
	public void LogW(String message) {}

	@Override
	public void LogE(String message) {}

	@Override
	public void LogV(String message, Throwable t) {}

	@Override
	public void LogI(String message, Throwable t) {}

	@Override
	public void LogD(String message, Throwable t) {}

	@Override
	public void LogW(String message, Throwable t) {}

	@Override
	public void LogE(String message, Throwable t) {}

}
