package com.roamtouch.gesturekit.log;

public interface LoggerInterface {
	public void LogV(String message);
	public void LogI(String message);
	public void LogD(String message);
	public void LogW(String message);
	public void LogE(String message);
	public void LogV(String message, Throwable t);
	public void LogI(String message, Throwable t);
	public void LogD(String message, Throwable t);
	public void LogW(String message, Throwable t);
	public void LogE(String message, Throwable t);
}
