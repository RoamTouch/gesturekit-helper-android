package com.roamtouch.gesturekit.communications;

import java.io.IOException;
import java.util.Hashtable;

import android.os.AsyncTask;
import android.os.Build;

import com.fasterxml.jackson.core.JsonParseException;
import com.roamtouch.gesturekit.data.Cache;
import com.roamtouch.gesturekit.data.GKPreferences;
import com.roamtouch.gesturekit.data.HelpParserJackson;
import com.roamtouch.gesturekit.data.HelpParserStream;
import com.roamtouch.gesturekit.data.HelpSet;
import com.roamtouch.gesturekit.data.JSONGenerator;

public class HelpTask extends AsyncTask<String, Void, Cache> {		
		
		String help_url;
		String UIID;
		String package_name;
		
		//private GetHTML get_html = new GetHTML();		
		
		private onHelpProgressUpdate onHelpProgressUpdate;
		private HelpListener helpListener;	

		private Cache cache;		
		
		public HelpTask(String url, String uiid, Cache c) {
			this.help_url = url;
			this.UIID = uiid;	
			this.cache = c;
		}				

		@Override
	    protected Cache doInBackground(String... param) {				
			
			try {		    	
				
				onHelpProgressUpdate.progress("Gesture call");  
								
				String complete_url = help_url + UIID;
							
				if(Build.VERSION.SDK_INT <= Build.VERSION_CODES.GINGERBREAD_MR1){
					HelpParserJackson helpParserJackson = new HelpParserJackson();
					cache = helpParserJackson.parse( cache, complete_url, package_name, onHelpProgressUpdate, helpListener);
				}else{
					HelpParserStream helpParserStream = new HelpParserStream();
					cache = helpParserStream.parse( cache, complete_url, package_name, onHelpProgressUpdate, helpListener);
				}		
				
			    	
			} catch (JsonParseException e) {			
				this.helpListener.jsonHelpFailed(e);
			} catch (IOException e) {				
				this.helpListener.jsonHelpFailed(e);			
			}
			
			return cache;
			
	    }
			
		public void setHelpListener(HelpListener helpListener) {
		       this.helpListener = helpListener;
		}
		
		public void setHelpProgressListener(onHelpProgressUpdate progress) {
		       this.onHelpProgressUpdate = progress;
		}	
	

		@Override
	    protected void onPostExecute(Cache cache) {
			
			if(cache != null)
	        {   
	        
				try {					
					
					onHelpProgressUpdate.progress("Store Gestures");	
					
					//Save helps per uiid
					HelpSet helpSet = null;
					for(String key : cache.getHelpSetsKeys()){
						helpSet = cache.getHelpSet(key);				
						GKPreferences.put(helpSet.getGid() + "_help_array", JSONGenerator.getHelpJSON(helpSet));
					}			
					
					onHelpProgressUpdate.progress("Cache: " + "help");
				
				} catch (Exception e) {	
					
					this.helpListener.jsonHelpFailed(e);				
				}	
								
				this.helpListener.jsonHelpSuccessfully(cache);
				
				
		    } else {
		    	
		    	//Throwable t = new Throwable("Cache object null..");
		        StackTraceElement[] trace = new StackTraceElement[] {
		           new StackTraceElement("HtmlTask","doInBackground","fileName",10)
		        };		        
		    	
		        Exception e = new Exception();
		    	e.setStackTrace(trace);
		    	
		       this.helpListener.jsonHelpFailed(e);
		       
		    }
		}
	 
		public static interface HelpListener {	        
	    	void jsonHelpSuccessfully(Cache cache);		
	        void jsonHelpFailed(Exception e);						
	    }  	
	    
	    public static interface onHelpProgressUpdate {	        
	    	String progress(String item);		        			
	    }
	    
}

	





