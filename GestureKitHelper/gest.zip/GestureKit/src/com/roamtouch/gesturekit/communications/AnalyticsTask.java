package com.roamtouch.gesturekit.communications;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.zip.GZIPInputStream;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.CoreProtocolPNames;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.os.AsyncTask;
import android.util.Log;

import com.roamtouch.gesturekit.GestureKit;


public class AnalyticsTask extends AsyncTask<String, Void, JSONObject> {		
	
		public String analytics_url = "http://www.gesturekit.com/sdk/sendanalytics/android/";	
	
		private GestureKit gK;
		private String UIID;
		private String device_id;
		private String platform;
		
		private AnalyticsPostListener analyticsListener;	
		
		public AnalyticsTask(GestureKit gK, String UIID, String device_id, String platform) {			
			this.gK = gK;
			this.UIID = UIID;
			this.device_id = device_id;
			this.platform = platform;			
		}				

		@Override
	    protected JSONObject doInBackground(String... param) {	
			
			JSONObject jsonObjRecv = null;
			List<NameValuePair> params = new ArrayList<NameValuePair>();
			String resultString = null;
			try {
				DefaultHttpClient httpclient = new DefaultHttpClient();
				HttpPost httpPostRequest = new HttpPost(this.analytics_url);

				JSONObject cacheToPost = getAnalyticsCache();
				
				if(cacheToPost == null || cacheToPost.getJSONArray("reports").length() <= 0){
					this.cancel(true);
					return null;
				}
				params.add(new BasicNameValuePair("json", cacheToPost.toString()));
				params.add(new BasicNameValuePair("gid", UIID));
				httpPostRequest.setEntity(new UrlEncodedFormEntity(params));
				httpPostRequest.getParams().setParameter(CoreProtocolPNames.USE_EXPECT_CONTINUE, Boolean.FALSE);
				
				//httpPostRequest.setHeader("Accept", "application/json");
				//httpPostRequest.setHeader("Content-type", "application/json");
				//httpPostRequest.setHeader("Accept-Encoding", "gzip"); // only set this parameter if you would like to use gzip compression
				
				HttpResponse response = (HttpResponse) httpclient.execute(httpPostRequest);
				HttpEntity entity = response.getEntity();

				if (entity != null) {		
					InputStream instream = entity.getContent();
					Header contentEncoding = response.getFirstHeader("Content-Encoding");
					if (contentEncoding != null && contentEncoding.getValue().equalsIgnoreCase("gzip")) {
						instream = new GZIPInputStream(instream);
					}
					resultString = convertStreamToString(instream);
					instream.close();
					jsonObjRecv = new JSONObject(resultString);					
				} 
			}
			catch (Exception e)
			{
				Log.e(this.getClass().getCanonicalName(), "post: " + params.toString());
				Log.e(this.getClass().getCanonicalName(), "response: " + resultString);
				e.printStackTrace();
			}
			
			return jsonObjRecv;		
	    }	
		
		
			
		private JSONObject getAnalyticsCache() {
		   
			JSONObject analytics = new JSONObject();			
			JSONArray reports = new JSONArray();	
			JSONArray gestures = new JSONArray();
			
			try {
				Iterator<?> iter = this.gK.getAnalytics().getAll().entrySet().iterator();
				
			    while (iter.hasNext()) {			    	
			        @SuppressWarnings("unchecked")
					Map.Entry<String, Integer> pair = (Map.Entry<String, Integer>)iter.next();
			        String method = (String) pair.getKey();
			        int amount = (Integer) pair.getValue();
			        
			        JSONObject gesture = new JSONObject();
			        gesture.put("count", amount);
			        gesture.put("gesture_id", method);
			        
			        if(amount > 0)
			        	gestures.put(gesture);			        			        
			    }
			    
			    if(gestures.length() == 0)
			    	return null;
			    
			    
			    JSONObject report = new JSONObject();
			    report.put("gestures", gestures);
			    report.put("date", Calendar.getInstance().getTimeInMillis()/1000);
			    reports.put(report);
			    
			    analytics.put("reports", reports);
			    analytics.put("platform_id", this.platform);
			    analytics.put("device_id", this.device_id);
			    analytics.put("uiid", this.UIID);

			} catch (JSONException e) {	
				this.analyticsListener.jsonAnalyticsFailed(e);
				e.printStackTrace();
			}   			
	
		return analytics;
	}   
		
	private static String convertStreamToString(InputStream is) {
			
			BufferedReader reader = new BufferedReader(new InputStreamReader(is));
			StringBuilder sb = new StringBuilder();

			String line = null;
			try {
				while ((line = reader.readLine()) != null) {
					sb.append(line + "\n");
				}
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				try {
					is.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			return sb.toString();
		}
		
	@Override
    protected void onPostExecute(JSONObject result) {
		this.analyticsListener.jsonAnalyticsSuccessfully(result);
	}
	
	public void setAnalyticsListener(AnalyticsPostListener analyticsListener) {
	       this.analyticsListener = analyticsListener;
	}	
		
	public static interface AnalyticsPostListener {	        
    	void jsonAnalyticsSuccessfully(JSONObject result);		
        void jsonAnalyticsFailed(Exception e);						
    }  	
    
    public static interface OnAnalyticsProgressUpdate {	        
    	String progress(String item);		        			
    } 
		
}

	





