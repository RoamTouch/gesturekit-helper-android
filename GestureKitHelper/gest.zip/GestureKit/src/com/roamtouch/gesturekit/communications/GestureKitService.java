package com.roamtouch.gesturekit.communications;

import android.app.Service;
import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;

import com.roamtouch.gesturekit.GestureKit;
import com.roamtouch.gesturekit.communications.CheckTask.CheckListener;
import com.roamtouch.gesturekit.communications.CheckTask.OnCheckProgressUpdate;
import com.roamtouch.gesturekit.data.Cache;

public class GestureKitService extends Service {
	
	public static final String ACTION_GESTURE_KIT = "com.roamtouch.gesturekit.communications.GestureKitService";
	public static final String RESULT = "result";
	
	public static final int RESULT_OFFLINE = 0, RESULT_JSON_FAILED = 1, RESULT_JSON_SUCCESS = 2, RESULT_JSON_SUCCESS_CACHE = 3;
	
	private boolean local;
	
	@Override
	public IBinder onBind(Intent i) {
		return null;
	}
	
	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		
		if (intent!=null){
		
			if( intent.getExtras() != null ){
				
				Bundle extras = intent.getExtras();
				String extra = extras.getString("local");
				
				if (extra.equals("true")){
					this.local = true;
				}
				
			}
		}
		
		if (!this.local){
			
			if (Connectivity.isOnline(this)){
				checkData();
			} else {
				publishResults(RESULT_OFFLINE);
			}
			
		}
			
		return super.onStartCommand(intent, flags, startId);
	}
	
	private void checkData() {
		
		// Check JSON / Get htmlset gestureset
		CheckTask check = new CheckTask(GestureKit.service_base_url, GestureKit.UIID);	    

		check.setCheckProgressUpdate(new OnCheckProgressUpdate(){
			@Override
			public String progress(String item) {
				GestureKit.getLogger().LogV("GK: " + item);				
				return null;
			}		
		});

		check.setCheckListener(new CheckListener(){
			@Override
			public void jsonCheckSuccessfully(Cache c) {		
				publishResults(RESULT_JSON_SUCCESS);		
			}
			@Override
			public void jsonCheckFailed(Exception e) {			
				publishResults(RESULT_JSON_FAILED);
			}
			@Override
			public void jsonCheckSuccessFromCache() {
				publishResults(RESULT_JSON_SUCCESS_CACHE);
			}	    					
		});	

		check.execute();
	}
	
	private void publishResults(int result){
		Log.d("GKService", "result: " + result);
		Intent i = new Intent(ACTION_GESTURE_KIT);
		i.putExtra(RESULT, result);
		sendBroadcast(i);
		stopSelf();
	}

}
