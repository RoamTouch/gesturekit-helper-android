package com.roamtouch.gesturekit.communications;

import java.io.IOException;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.os.AsyncTask;

import com.roamtouch.gesturekit.data.Cache;
import com.roamtouch.gesturekit.data.GKPreferences;
import com.roamtouch.gesturekit.data.Html;
import com.roamtouch.gesturekit.data.Htmls;

public class HtmlTask extends AsyncTask<String, Void, Cache> {		
		
		private Cache cache;
		private String html_url;
		private String UIID;		
		
		private GetHTML get_html = new GetHTML();		
		
		private onHtmlProgressUpdate onHtmlProgressUpdate;
		private HtmlLoadListener htmlLoadListener;		
		
		public HtmlTask(String url, String uiid, Cache c) {		
			this.UIID = uiid;	
			this.html_url = url;
			this.cache = c;
		}			

		@Override
	    protected Cache doInBackground(String... param) {				
			
			try {		    	
				
				onHtmlProgressUpdate.progress("HTML call");  					
				DefaultHttpClient client = new DefaultHttpClient();
				
				String complete_url = this.html_url + UIID;
		    	
		    	HttpGet get = new HttpGet( complete_url  );	    
		    	   	
		    	HttpResponse responseGet = client.execute(get);		    	
		    	HttpEntity resEntityGet = responseGet.getEntity();		
		    	
		    	if (resEntityGet != null) {
		      	  		    		
		    	    String json = EntityUtils.toString(resEntityGet);
		    	    JSONObject html_obj = new JSONObject(json);   		    	    	   
		    	    
		    	    if( !html_obj.has("error") ) {    	     	  	
		    	    	JSONArray html_array = html_obj.getJSONArray("html");	     			    	    		
	    	    		Htmls htmls = new Htmls();

		    	    	for (int i=0; i < html_array.length(); i++)
		    	    	{
		    	    		
		    	    	    JSONObject html_gesture_object = html_array.getJSONObject(i);	    	    	   
		    	    	   
		    	    	    String src = html_gesture_object.getString("src");
		    	    	    String url = html_gesture_object.getString("url");		
		    	    	    
		    	    	    url = get_html.get(url);   	    	   
		    	    	    
		    	    	    Html h = new Html();
		    	    	    h.setSource(src);
		    	    	    h.setCode(url);
		    	    	    htmls.putHtml(src, h);
		    	    	    
		    	    	    onHtmlProgressUpdate.progress("Get page: " + src);    	    	    
		    	    	}
		    	    	cache.putHtmls("htmls", htmls);	    	    		    			    	    	
		    	    }	    
		    	}   		    	
		    
		    	save_html_result_to_cache(cache);
		    	
			} catch (JSONException e) {	
				this.htmlLoadListener.HtmlLoadFailed(e);				
			} catch (IOException e) {	
				this.htmlLoadListener.HtmlLoadFailed(e);				
			}	
			
			return cache;
			
	    }
		
		
		
		/**
		 * save_html_result_to_cache
		 * By passing the Cache just loaded into json the Sharedpreference HTML editor is populated. 
		 * @param c
		 */
		public void save_html_result_to_cache (Cache c){
			
			try {	
				
				Htmls htmls = c.getHtmls("htmls");
				
				onHtmlProgressUpdate.progress("Cache: " + "index.html");	
				
				Html index = htmls.getHtmlByKeyLike("index"); 	
				if (index!=null){
					String imdex_code = index.getCode();
					GKPreferences.add_data_to_cache("index", imdex_code);
				}
				
				onHtmlProgressUpdate.progress("Cache: " + "jquery.js");
				
				Html jquery = htmls.getHtmlByKeyLike("jquery-1.9.1");
				if (jquery!=null){
					String jquery_code = jquery.getCode();
					GKPreferences.add_data_to_cache("jquery", jquery_code);
				}			
				
				onHtmlProgressUpdate.progress("Cache: " + "pdollar.js");
				
				Html pdollar = htmls.getHtmlByKeyLike("pdollar");
				if (pdollar!=null){
					String pdollar_code = pdollar.getCode();
					GKPreferences.add_data_to_cache("pdollar", pdollar_code);
				}		
			
				onHtmlProgressUpdate.progress("Cache: " + "observer.js");
				
				Html observer = htmls.getHtmlByKeyLike("observer");
				if (observer!=null){
					String observer_code = observer.getCode();
					GKPreferences.add_data_to_cache("observer", observer_code);				
				}		
				
				// Set html cache loaded. 
				GKPreferences.add_data_to_cache("has_html_cache", true);
				//prefs_editor.putBoolean("has_html_cache", true);
				
				// Application type to cache. 
				GKPreferences.add_data_to_cache("application_type", c.get_application_type());
				//prefs_editor.putInt("application_type", c.get_application_type());
				
				onHtmlProgressUpdate.progress("Cache: " + "html finished");			
				
			} catch (Exception e) {	
				
				this.htmlLoadListener.HtmlLoadFailed(e);				
			}		

		}	
		
		@Override
	    protected void onPostExecute(Cache cache) {
			
			if(cache != null)
	        {               
				
				this.htmlLoadListener.HtmlLoadedSuccessfully(cache);
				
		    } else {
		        StackTraceElement[] trace = new StackTraceElement[] {
		           new StackTraceElement("HtmlTask","doInBackground","fileName",10)
		        };		        
		    	Exception e = new Exception();
		    	e.setStackTrace(trace);
		    	
		        this.htmlLoadListener.HtmlLoadFailed(e);
		    }    
		}	
		
		public void setHtmlLoadListener(HtmlLoadListener htmlLoadListener) {
		       this.htmlLoadListener = htmlLoadListener;
		}
		
	    public static interface HtmlLoadListener {	        
	    	void HtmlLoadedSuccessfully(Cache cache);		
	        void HtmlLoadFailed(Exception e);						
	    }  	
	    
	    public void setHtmlProgressListener(onHtmlProgressUpdate progress) {
		       this.onHtmlProgressUpdate = progress;
		}
	    
	    public static interface onHtmlProgressUpdate {	        
	    	String progress(String item);		        			
	    }  
		    
}

	





