package com.roamtouch.gesturekit.communications;

import java.io.IOException;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;

import android.os.AsyncTask;

import com.roamtouch.gesturekit.GestureKit;
import com.roamtouch.gesturekit.communications.GestureTask.GestureListener;
import com.roamtouch.gesturekit.communications.GestureTask.onGestureProgressUpdate;
import com.roamtouch.gesturekit.communications.HelpTask.HelpListener;
import com.roamtouch.gesturekit.communications.HelpTask.onHelpProgressUpdate;
import com.roamtouch.gesturekit.communications.HtmlTask.HtmlLoadListener;
import com.roamtouch.gesturekit.communications.HtmlTask.onHtmlProgressUpdate;
import com.roamtouch.gesturekit.communications.HtmlTask.HtmlLoadListener;
import com.roamtouch.gesturekit.communications.HtmlTask.onHtmlProgressUpdate;
import com.roamtouch.gesturekit.data.Cache;
import com.roamtouch.gesturekit.data.GKPreferences;

public class CheckTask extends AsyncTask<String, Void, Long[]> {		
		
		private static Cache cache;	
		
		private String UIID;			
		
		private HtmlTask htmlTask;
		private GestureTask gestureTask;
		private HelpTask helpTask;
		
		private CheckListener checkListener;	
		private OnCheckProgressUpdate onCheckProgressUpdate;
				
		public String API;

		public String gesture_update = "/index.php/sdk/getupdate/";		
		public String html_cache_url = "/index.php/sdk/gethtml/android/";		
		public String gesture_cache_url = "/index.php/sdk/getgestures/";		
		public String help_cache_url = "/index.php/sdk/getgestures_help/";

		public CheckTask(String base_url, String uiid) {
			
			API = GestureKit.get_api_version();
			
			base_url = base_url + API;
			
			gesture_update = base_url  + gesture_update;			
			html_cache_url = base_url + html_cache_url;
			gesture_cache_url = base_url + gesture_cache_url;
			help_cache_url = base_url + help_cache_url;
					
			this.UIID = uiid;
			this.cache = new Cache();
			
		}	

		@Override
	    protected Long[] doInBackground(String... param) {					
			
			Long[] check_object = null;
			
			try {		
				
				DefaultHttpClient client = new DefaultHttpClient();
				String complete_url = gesture_update + UIID;		    	
		    	HttpGet get = new HttpGet( complete_url  );	    
		    	HttpResponse responseGet = client.execute(get);		    	
		    	HttpEntity resEntityGet = responseGet.getEntity();		
		    	
		    	if (resEntityGet != null) {	    		
		      	  		    		
		    	    String json = EntityUtils.toString(resEntityGet);
		    	    JSONObject check_obj = new JSONObject(json); 
		    	    
		    	    String status = check_obj.getString("status");
		    	    
		    	    // REMOVE ME
		    	   long timeSinceMidnight =  GestureKit.getTimeSinceMidnight();
		    	    
		    	   //if (!status.equals("0")){
		    	    	
		    	    	  //long html_update_time = check_obj.getLong("html_update");		    	    
				    	  //long gesture_update_time = check_obj.getLong("gesture_update");		 
				    	 
		    		   	long html_update_time = timeSinceMidnight;
		    		   	long gesture_update_time = timeSinceMidnight;
		    		   
				    	  //JSONObject content = check_obj.getJSONArray("content").getJSONObject(0);			    	    
				    	  //cache = GKPreferences.set_prefs_values(content, cache);	    		   
		    		   
				    	  check_object = new Long[2];
				    	    
				    	  check_object[0] = html_update_time;
				    	  check_object[1] = gesture_update_time;
		    	    	
		    	   //} else {  	    	
		    	    	
		    	    	
		    	    //}
		    	  
		    	    
		    	}   		    	
		    	
			} catch (JSONException e) {	
				this.checkListener.jsonCheckFailed(e);				
			} catch (IOException e) {				
				this.checkListener.jsonCheckFailed(e);				
			}		      	
			
			return check_object;
			
	    }	

		@Override
	    protected void onPostExecute(final Long[] check_object) {
			
			if (check_object!=null){			
			
				final long html_update_time = check_object[0];						 
				
				long cache_html_update = 0;
				
				// Temporary fix
				try 
				{
					cache_html_update = GKPreferences.getLong("html_update");
				}
				catch (Exception e)
				{
					return;
				}
				
		    	    
		    	if ( cache_html_update != html_update_time) {	 
		    		 
		    		htmlTask = new HtmlTask(this.html_cache_url, this.UIID, this.cache);	   		    		
				 		
		    		htmlTask.setHtmlLoadListener(new HtmlLoadListener() {
	
							@Override
							public void HtmlLoadedSuccessfully(Cache c) {
								c.set_html_update_time(html_update_time);													
								GKPreferences.put("html_update", c.get_html_update_time());
								load_gestures(check_object[1], c);
								cache = c; 		
							}
		
							@Override
							public void HtmlLoadFailed(Exception e) {
								checkListener.jsonCheckFailed(e);		
							}						
				 			 
				 	});			
				
				 	htmlTask.setHtmlProgressListener(new onHtmlProgressUpdate(){

						@Override
						public String progress(String item) {
							onCheckProgressUpdate.progress(item);
							return null;
						}				
					 
				 	});				
				 		
					htmlTask.execute();
		    		 
		    	 }	else {
		    		 
		    		 // Html no update check gestures.
		    		 load_gestures(check_object[1], cache);
		    		 
		    	 }
		    
			}
	}
		
		
	private void load_gestures(final long gesture_update_time, final Cache c){    	 
				
		long cache_gesture_update = GKPreferences.getLong("gesture_update");			
			 
		if ( gesture_update_time != cache_gesture_update) {
				 
			gestureTask = new GestureTask(this.gesture_cache_url, this.UIID, c); 		
			
			gestureTask.setGestureProgressListener(new onGestureProgressUpdate(){

				@Override
				public String progress(String log) {	
					onCheckProgressUpdate.progress(log);
					return null;
				}
				
			});		
			
			gestureTask.setGestureListener(new GestureListener(){

				@Override
				public void jsonGestureSuccessfully(Cache c) {
					GKPreferences.put("gesture_update", gesture_update_time);	
					load_help_data(c);
				}

				@Override
				public void jsonGestureFailed(Exception e) {
					checkListener.jsonCheckFailed(e);					
				}
				
			});
			
			gestureTask.execute();
				 
		} else {
			
			 // Html no update check gestures.
			load_help_data(cache);		
			
		}
	}	
	
	public static Cache getCache() {
		return cache;
	}

	private void load_help_data(final Cache c){ 
		
		helpTask = new HelpTask(this.help_cache_url, this.UIID, c); 		
		
		helpTask.setHelpProgressListener(new onHelpProgressUpdate(){

			@Override
			public String progress(String log) {	
				onCheckProgressUpdate.progress(log);
				return null;
			}
			
		});		
		
		helpTask.setHelpListener(new HelpListener(){

			@Override
			public void jsonHelpSuccessfully(Cache c) {					
				checkListener.jsonCheckSuccessfully(c);					
			}

			@Override
			public void jsonHelpFailed(Exception e) {
				checkListener.jsonCheckFailed(e);					
			}
			
		});
		
		helpTask.execute();
				 
	}	
	
	public void setCheckListener(CheckListener checkListener) {
	       this.checkListener = checkListener;
	}	
	
	public void setCheckProgressUpdate(OnCheckProgressUpdate onCheckProgressUpdate) {
	       this.onCheckProgressUpdate = onCheckProgressUpdate;
	}
	
    public static interface CheckListener {	        
    	void jsonCheckSuccessfully(Cache cache);	
    	void jsonCheckSuccessFromCache();
        void jsonCheckFailed(Exception e);						
    }  	
    
    public static interface OnCheckProgressUpdate {	        
    	String progress(String item);		        			
    }  

}





