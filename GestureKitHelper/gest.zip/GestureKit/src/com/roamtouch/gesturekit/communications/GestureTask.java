package com.roamtouch.gesturekit.communications;

import java.io.IOException;
import java.util.Hashtable;

import android.os.AsyncTask;
import android.os.Build;

import com.fasterxml.jackson.core.JsonParseException;
import com.roamtouch.gesturekit.data.Cache;
import com.roamtouch.gesturekit.data.GKPreferences;
import com.roamtouch.gesturekit.data.GestureParserJackson;
import com.roamtouch.gesturekit.data.GestureParserStream;
import com.roamtouch.gesturekit.data.HelpParserStream;
import com.roamtouch.gesturekit.data.GestureSet;
import com.roamtouch.gesturekit.data.Gestures;
import com.roamtouch.gesturekit.data.JSONGenerator;

public class GestureTask extends AsyncTask<String, Void, Cache> {		
		
		String gesture_url;
		String UIID;
		String package_name;
		
		//private GetHTML get_html = new GetHTML();		
		
		private onGestureProgressUpdate onGestureProgressUpdate;
		private GestureListener gestureListener;	

		private Cache cache;		
		
		public GestureTask(String url, String uiid, Cache c) {
			this.gesture_url = url;
			this.UIID = uiid;	
			this.cache = c;
		}				

		@Override
	    protected Cache doInBackground(String... param) {				
			
			try {		    	
				
				onGestureProgressUpdate.progress("Gesture call");  
								
				String complete_url = gesture_url + UIID;
				
				if(Build.VERSION.SDK_INT <= Build.VERSION_CODES.GINGERBREAD_MR1){
					GestureParserJackson gestureParserJackson = new GestureParserJackson();
					cache = gestureParserJackson.parse( cache, complete_url, package_name, onGestureProgressUpdate, gestureListener);
				} else {
					GestureParserStream gestureParserStream = new GestureParserStream();
					cache = gestureParserStream.parse( cache, complete_url, package_name, onGestureProgressUpdate, gestureListener);
				}
				
				onGestureProgressUpdate.progress("Cache: " + "metadata");
				
				Hashtable<String, String> metadata = new Hashtable<String, String>();
				for(Gestures gestures : cache.getGestureSet(UIID).getGestures())
					if(gestures.getMetadata() != null && gestures.getMetadata().length() > 0)
						metadata.put(gestures.getMethod(), gestures.getMetadata());

				GKPreferences.add_data_to_cache("metadata", metadata.toString());
			    	
			} catch (JsonParseException e) {			
				this.gestureListener.jsonGestureFailed(e);
			} catch (IOException e) {				
				this.gestureListener.jsonGestureFailed(e);			
			}
			
			return cache;
			
	    }
			
		
		
		
		public void setGestureListener(GestureListener gestureListener) {
		       this.gestureListener = gestureListener;
		}
		
		public void setGestureProgressListener(onGestureProgressUpdate progress) {
		       this.onGestureProgressUpdate = progress;
		}	
	

		@Override
	    protected void onPostExecute(Cache cache) {
			
			if(cache != null)
	        {   
	        
				try {					
					
					onGestureProgressUpdate.progress("Store Gestures");	
					
					//Save gesturesets per uiid
					GestureSet gestureSet = null;
					for(String key : cache.getGestureSetsKeys()){
						gestureSet = cache.getGestureSet(key);				
						GKPreferences.put(gestureSet.getGid(), JSONGenerator.getJSON(gestureSet));
					}			
					
					//onGestureProgressUpdate.progress("Cache: " + "html_help");					
					// Help array
					//GKPreferences.add_data_to_cache("help_array", JSONGenerator.getJSON(cache.getMethodsHelp()));
								
					// Set gesture cache loaded. 
					GKPreferences.add_data_to_cache("has_gesture_cache", true);			
					
				} catch (Exception e) {	
					
					this.gestureListener.jsonGestureFailed(e);				
				}	
								
				this.gestureListener.jsonGestureSuccessfully(cache);
				
				
		    } else {
		    	
		    	//Throwable t = new Throwable("Cache object null..");
		        StackTraceElement[] trace = new StackTraceElement[] {
		           new StackTraceElement("HtmlTask","doInBackground","fileName",10)
		        };		        
		    	
		        Exception e = new Exception();
		    	e.setStackTrace(trace);
		    	
		       this.gestureListener.jsonGestureFailed(e);
		       
		    }
		}
	 
		public static interface GestureListener {	        
	    	void jsonGestureSuccessfully(Cache cache);		
	        void jsonGestureFailed(Exception e);						
	    }  	
	    
	    public static interface onGestureProgressUpdate {	        
	    	String progress(String item);		        			
	    }  
	    
}

	





