package com.roamtouch.gesturekit.communications;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

public class GetHTML {

	public String get(String url) {
		
		HttpClient httpclient = new DefaultHttpClient(); 
		
		HttpGet httpget = new HttpGet(url); 
		HttpResponse response = null;
		try {
			response = httpclient.execute(httpget);			
		} catch (ClientProtocolException e) {			
			e.printStackTrace();
		} catch (IOException e) {	
			e.printStackTrace();
		} 
		
		HttpEntity entity = response.getEntity(); 
		InputStream is = null;
		try {
			is = entity.getContent();
		} catch (IllegalStateException e) {			
			e.printStackTrace();
		} catch (IOException e) {			
			e.printStackTrace();
		} 
		
		BufferedReader reader = null;
		try {
			reader = new BufferedReader(new InputStreamReader(is, "UTF-8"), 8);
		} catch (UnsupportedEncodingException e) {			
			e.printStackTrace();
		}
		
		StringBuilder sb = new StringBuilder();
		
		String line = null;
		
		try {
			while ((line = reader.readLine()) != null) 
			    sb.append(line + "\n");
		} catch (IOException e) {			
			e.printStackTrace();
		}
	
		String resString = sb.toString(); 
		try {
			is.close();
		} catch (IOException e) {			
			e.printStackTrace();
		} 
		
		return resString;	   
		
	}
	
}
