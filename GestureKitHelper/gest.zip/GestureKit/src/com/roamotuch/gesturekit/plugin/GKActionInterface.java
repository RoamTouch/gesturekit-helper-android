package com.roamotuch.gesturekit.plugin;

public interface GKActionInterface {
	public String getActionID();
	public void onGestureRecognized(Object... params);
	public String getPackageName();
}
