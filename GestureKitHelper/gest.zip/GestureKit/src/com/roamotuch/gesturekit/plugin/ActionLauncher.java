package com.roamotuch.gesturekit.plugin;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.util.Log;

import com.roamotuch.gesturekit.plugin.GKActionInterface;
import com.roamotuch.gesturekit.plugin.PluginAction;
import com.roamtouch.gesturekit.GestureKit;


public class ActionLauncher extends PluginAction implements GKActionInterface {

	private Activity activity;	
	private GestureKit gk;	
	private String packagename;
	private String name;
		
	public ActionLauncher(Activity activity, GestureKit gk, String name, String packagename){		
		super(activity);
		this.activity = activity;
		this.gk = gk;	
		this.name = name;
		this.packagename = packagename;
	}
	
	public void setPackageName(String packagename) {
		this.packagename = packagename;
	}
	
	@Override
	public String getActionID() {
		return "HANGOUT";
	}

	@Override
	public void onGestureRecognized(Object... params) {	
		
		try {
			
			if (params.length > 0 && params[0].equals("CLEAR_VISOR"))
			{
				Intent intent = new Intent();
				intent.setAction("VANISH_PARTICLES");
				this.activity.sendBroadcast(intent);

				Handler handler = new Handler();
				handler.postDelayed(new Runnable()
				{

					@Override
					public void run()
					{
						Intent intent = new Intent();
						intent.setAction("STOP_VANISH_PARTICLES");
						activity.sendBroadcast(intent);
					}
				}, 100);

				return;
			}
			
			Intent intent = new Intent();
			intent.setAction("BREAK_PARTICLES");
			this.activity.sendBroadcast(intent);
				
			
			Handler handler = new Handler(); 
		    handler.postDelayed(new Runnable() { 
		         public void run() { 
			 		Intent intent = new Intent();
					intent.setAction("STOP_BREAK_PARTICLES");
					activity.sendBroadcast(intent);
						
		        	 Intent LaunchIntent = activity.getPackageManager().getLaunchIntentForPackage(packagename);
		 			LaunchIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		 			activity.startActivity(LaunchIntent);
		 			
		         } 
		    }, 1500); 
			
					
		}  catch (Exception e) {
			Log.v("","");
		}
		
		
		
		Intent LaunchIntent = this.activity.getPackageManager().getLaunchIntentForPackage(packagename);
		this.activity.startActivity(LaunchIntent);		
	}

	@Override
	public String getPackageName() {
		// TODO Auto-generated method stub
		return null;
	}
}
