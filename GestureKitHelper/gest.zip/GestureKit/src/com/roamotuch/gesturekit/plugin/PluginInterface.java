package com.roamotuch.gesturekit.plugin;

import java.util.Map;
import com.roamtouch.gesturekit.GestureKit;
import com.roamtouch.gesturekit.data.PluginParams;
import android.view.MotionEvent;

public interface PluginInterface {
	public void onGesturesIcon(GestureKit gk, Map<String, String> icons);
    public void proccessTouchEvent(MotionEvent event);
    public void clear();
    public void showErrorLogo();
    public void showLoadingLogo();
    public void showOkLogo();
	public void setVisibility(int invisible);
	public void setPluginParams(PluginParams params);
	public PluginParams getPluginParams();
}


