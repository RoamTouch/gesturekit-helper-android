package com.roamotuch.gesturekit.plugin;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import android.app.Activity;
import android.util.Log;

import com.roamtouch.gesturekit.GestureKit;

public class GestureKitPlugins {	
	
	private PluginAction pluginAction;
	
	private static Activity activity;
	
	private Map<String, GKActionInterface> plugins;	
	
	private Hashtable methods_packages = new Hashtable();
	
	// Singleton
	private static GestureKitPlugins _instance;	
	
	private GKActionInterface ACTION; 
	
	public GestureKitPlugins(Activity activity) {				
		_instance = this;
		this.activity = activity;			
		plugins = new HashMap<String, GKActionInterface>();				
	}

	public static GestureKitPlugins getInstance()
    {
        if (_instance == null)
        {
            _instance = new GestureKitPlugins(activity);
        }
        return _instance;
    }
		
	public void setAction(GKActionInterface action, final String functionName) {
		plugins.put(functionName, action);	
	}
		
		
	public GKActionInterface getActionByName(String functionName){		
		GKActionInterface action = null;		
		try {		
			Iterator iterator = this.plugins.entrySet().iterator();			
			while (iterator.hasNext()) {				
				Map.Entry mapEntry = (Map.Entry) iterator.next();				
				if ( functionName.equals(mapEntry.getKey().toString()) ){	
					return plugins.get(functionName);				
				}
			}		
		}  catch (Exception e) {  
			Log.v("","");			
		}				
		return action;		
	}		

}
