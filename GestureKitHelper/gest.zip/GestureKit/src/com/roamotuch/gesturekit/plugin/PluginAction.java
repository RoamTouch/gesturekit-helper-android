package com.roamotuch.gesturekit.plugin;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.roamotuch.gesturekit.plugin.GKActionInterface;
import com.roamtouch.gesturekit.GestureKit;

import android.R;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.util.Log;

public class PluginAction extends Activity implements GKActionInterface {

	private Activity activity;	
	
	private String name;
	
	GKActionInterface action;	
		
	public GKActionInterface getAction() {
		return action;
	}

	public void setAction(GKActionInterface action) {
		this.action = action;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public PluginAction(Activity activity){		
		this.activity = activity;		
	}	


	@Override
	public String getActionID() {
		return name;
	}

	@Override
	public void onGestureRecognized(Object... params) {	
		
	}
	
	
}
