/** Automatically generated file. DO NOT MODIFY */
package com.roamtouch.gesturekit;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}